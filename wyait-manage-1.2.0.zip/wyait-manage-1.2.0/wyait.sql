/*
Navicat MySQL Data Transfer

Source Server         : shuai
Source Server Version : 50527
Source Host           : localhost:3306
Source Database       : wyait

Target Server Type    : MYSQL
Target Server Version : 50527
File Encoding         : 65001

Date: 2019-02-28 22:10:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `attendance`
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int(10) NOT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `userid` int(10) NOT NULL,
  `spring` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aa` (`userid`),
  CONSTRAINT `aa` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of attendance
-- ----------------------------

-- ----------------------------
-- Table structure for `dept`
-- ----------------------------
DROP TABLE IF EXISTS `dept`;
CREATE TABLE `dept` (
  `id` double NOT NULL DEFAULT '0',
  `name` varchar(90) DEFAULT NULL,
  `deptTel` double DEFAULT NULL,
  `introduce` varchar(1800) DEFAULT NULL,
  `version` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dept
-- ----------------------------
INSERT INTO `dept` VALUES ('1534', '阿外通信', '68977288', '连接通信资源，提供专业互联网创新型通信产品和服务', '0');
INSERT INTO `dept` VALUES ('2357', '技术保障', '63073111', '规划、设计、运行数据中心和网络，掌控集团交易、支付、云计算及大数据平台', '0');
INSERT INTO `dept` VALUES ('2387', '搜索事业部', '63076206', '海量用户数据、庞大几机器规模，以及全链路实时反馈的需求，带给我们无穷的技术挑战', '0');

-- ----------------------------
-- Table structure for `email`
-- ----------------------------
DROP TABLE IF EXISTS `email`;
CREATE TABLE `email` (
  `EmailId` int(10) NOT NULL,
  `SendId` int(20) NOT NULL,
  `receiveId` int(20) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `info` varchar(100) DEFAULT NULL,
  `time` date DEFAULT NULL,
  `extraAddress` varchar(100) DEFAULT NULL,
  `booleanDel` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`EmailId`),
  KEY `sendId` (`SendId`),
  KEY `receiveId` (`receiveId`),
  CONSTRAINT `receiveId` FOREIGN KEY (`receiveId`) REFERENCES `user` (`id`),
  CONSTRAINT `sendId` FOREIGN KEY (`SendId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of email
-- ----------------------------

-- ----------------------------
-- Table structure for `extrawork`
-- ----------------------------
DROP TABLE IF EXISTS `extrawork`;
CREATE TABLE `extrawork` (
  `id` int(20) NOT NULL DEFAULT '0',
  `deptNo` int(20) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `info` varchar(20) DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `endtime` datetime DEFAULT NULL,
  `userid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `no` (`deptNo`),
  KEY `dd` (`userid`),
  CONSTRAINT `dd` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of extrawork
-- ----------------------------

-- ----------------------------
-- Table structure for `gangwei`
-- ----------------------------
DROP TABLE IF EXISTS `gangwei`;
CREATE TABLE `gangwei` (
  `id` int(10) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `deptno` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ee` (`deptno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of gangwei
-- ----------------------------

-- ----------------------------
-- Table structure for `kaoqintongji`
-- ----------------------------
DROP TABLE IF EXISTS `kaoqintongji`;
CREATE TABLE `kaoqintongji` (
  `userId` int(20) NOT NULL,
  `id` int(10) NOT NULL,
  `worklv` varchar(10) DEFAULT NULL,
  `chidao` varchar(10) DEFAULT NULL,
  `zaotui` varchar(10) DEFAULT NULL,
  `kuang` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`userId`),
  CONSTRAINT `id` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kaoqintongji
-- ----------------------------

-- ----------------------------
-- Table structure for `log`
-- ----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(10) NOT NULL,
  `userName` varchar(10) DEFAULT NULL,
  `result` varchar(10) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of log
-- ----------------------------
INSERT INTO `log` VALUES ('1', '111', '鐧婚檰鎴愬姛', '192.168.88.132', '2019-02-27 06:00:00');
INSERT INTO `log` VALUES ('2', '222', '鐧诲綍鎴愬姛', '192.168.77.111', '2019-02-11 09:35:50');
INSERT INTO `log` VALUES ('3', '333', '鐧婚檰鎴愬姛', '192.168.999.222', '2019-02-28 10:39:35');

-- ----------------------------
-- Table structure for `message`
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `information` text NOT NULL,
  `notifier` varchar(255) NOT NULL,
  `insert_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('1', '题目', '信息', '通知人', '2017-12-20 16:27:03');
INSERT INTO `message` VALUES ('2', 'dsa ', '发的红包飞', '购房人和规范', '2019-02-27 18:22:23');
INSERT INTO `message` VALUES ('3', 'cdsc', '第三方', 'dv', '2019-02-27 18:26:38');
INSERT INTO `message` VALUES ('4', 'sa ', '是发的v', 'VDS', '2019-02-27 18:27:57');
INSERT INTO `message` VALUES ('5', '的深V', '表达式', '是dsvv', '2019-02-27 18:28:50');
INSERT INTO `message` VALUES ('6', '表达式', '表达式', '表达式', '2019-02-27 18:28:56');
INSERT INTO `message` VALUES ('7', '表达式', '', '', '2019-02-27 18:29:01');
INSERT INTO `message` VALUES ('8', '但是', '表达式', '不是的', '2019-02-27 18:44:51');
INSERT INTO `message` VALUES ('9', '1', '1', '1', '2019-02-27 18:46:11');
INSERT INTO `message` VALUES ('10', 'safs', 'safas', 'saf', '2019-02-27 19:57:43');
INSERT INTO `message` VALUES ('11', 'safsaf', 'fsafsa', 'fsafsa', '2019-02-27 19:57:47');
INSERT INTO `message` VALUES ('12', 'fdsfdsafsa', 'fsafsajugfedwq', 'fsafsafsafsa', '2019-02-27 19:57:53');
INSERT INTO `message` VALUES ('13', 'dshujfwsakj', 'dn jdsakbjfkbvkj', ';lkhgds', '2019-02-27 19:58:02');
INSERT INTO `message` VALUES ('14', 'vfsadlkmbv;lkdsamn;nbv', 'mnbfd;lm\r\n', 'ngkldsrfn', '2019-02-27 19:58:09');
INSERT INTO `message` VALUES ('15', 'sgvdsgvdshglkdsawqjgvdsakgvp[edwsalbfdslbkeapolkgvpw[]sa', 'bvdsbvds', 'gdsa', '2019-02-27 19:58:17');
INSERT INTO `message` VALUES ('16', '系统通知', '学院规定 由于系统开始考勤管理 规定员工每天按时签到按时签退 一天只能签到一次', '李帅帅', '2019-02-27 21:30:23');

-- ----------------------------
-- Table structure for `permission`
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '菜单名称',
  `pid` int(11) DEFAULT NULL COMMENT '父菜单id',
  `zindex` int(2) DEFAULT NULL COMMENT '菜单排序',
  `istype` int(1) DEFAULT NULL COMMENT '权限分类（0 菜单；1 功能）',
  `descpt` varchar(50) DEFAULT NULL COMMENT '描述',
  `code` varchar(20) DEFAULT NULL COMMENT '菜单编号',
  `icon` varchar(30) DEFAULT NULL COMMENT '菜单图标名称',
  `page` varchar(50) DEFAULT NULL COMMENT '菜单url',
  `insert_time` datetime DEFAULT NULL COMMENT '添加时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES ('1', '系统管理', '0', '100', '0', '系统管理', 'system', '', '/', '2017-12-20 16:22:43', '2018-01-09 19:26:36');
INSERT INTO `permission` VALUES ('2', '用户管理', '1', '1100', '0', '用户管理', 'usermanage', '', '/user/userList', '2017-12-20 16:27:03', '2018-01-09 19:26:30');
INSERT INTO `permission` VALUES ('3', '角色管理', '1', '1200', '0', '角色管理', 'rolemanage', '', '/auth/roleManage', '2017-12-20 16:27:03', '2018-01-09 19:26:42');
INSERT INTO `permission` VALUES ('4', '权限管理', '1', '1300', '0', '权限管理', 'permmanage', null, '/auth/permList', '2017-12-30 19:17:32', '2018-01-09 19:26:48');
INSERT INTO `permission` VALUES ('5', '岗位管理', '0', '300', '0', '岗位管理', 'job', null, '/job/manage', '2017-12-30 19:17:50', '2018-01-09 19:20:11');
INSERT INTO `permission` VALUES ('6', '部门管理', '0', '200', '0', '部门管理', 'dept', null, '/dept/manage', '2018-01-01 11:07:17', '2018-01-09 19:05:42');
INSERT INTO `permission` VALUES ('8', '岗位列表', '5', '1121310', '0', '岗位列表', 'quartersmanage', null, '/quarters/quartersList', '2018-01-09 09:26:53', '2019-02-27 16:24:05');
INSERT INTO `permission` VALUES ('10', '岗位删除', '5', '2200', '0', '岗位删除', 'postdel', null, '/job/del', '2018-01-09 19:07:05', '2018-01-09 19:31:13');
INSERT INTO `permission` VALUES ('11', '岗位添加', '5', '2300', '0', '岗位添加', 'postadd', null, '/job/add', '2018-01-09 19:07:52', '2018-01-18 14:08:08');
INSERT INTO `permission` VALUES ('13', '岗位修改', '5', '3100', '0', '岗位修改', 'posdupdate', null, '/job/update', '2018-01-09 19:33:53', '2018-04-22 21:18:11');
INSERT INTO `permission` VALUES ('14', '通知', '0', '4100', '0', '通知', 'message', null, '/message', '2018-01-09 19:34:33', '2018-04-22 21:17:58');
INSERT INTO `permission` VALUES ('15', '审批流转', '0', '1200', '0', '审批流转', 'approval', null, '/approval/flow', '2019-02-25 09:16:09', '2019-02-25 09:21:03');
INSERT INTO `permission` VALUES ('16', '审批流程管理', '15', '1300', '0', '审批流程管理', 'approvalprocess', null, '/approval/manage', '2019-02-25 10:09:00', '2019-02-25 09:21:03');
INSERT INTO `permission` VALUES ('17', '起草申请', '15', '1400', '0', '起草申请', 'startapproval', null, '/approval/apply', '2019-02-25 10:09:07', '2019-02-25 09:21:03');
INSERT INTO `permission` VALUES ('18', '待我审批', '15', '1500', '0', '待我审批', 'approvaltomy', null, '/approval/tomy', '2019-02-25 10:09:16', '2019-02-25 09:21:03');
INSERT INTO `permission` VALUES ('19', '我的申请查询', '15', '1600', '0', '我的申请查询', 'myapproval', null, '/approval/my', '2019-02-25 10:09:19', '2019-02-25 09:21:03');
INSERT INTO `permission` VALUES ('20', '日志管理', '0', '1700', '0', '日志管理', 'logmanage', null, '/log/manage', '2019-02-25 10:29:40', '2019-02-25 09:21:03');
INSERT INTO `permission` VALUES ('21', '登录日志', '20', '1800', '0', '登录日志', 'loginlog', null, '/log/login', '2019-02-25 10:30:02', null);
INSERT INTO `permission` VALUES ('22', '访问日志', '20', '1900', '0', '访问日志', 'logvisit', null, '/log/visit', '2019-02-25 10:30:06', null);
INSERT INTO `permission` VALUES ('23', '图表统计', '20', '2000', '0', '图表统计', 'logcharts', null, '/log/charts', '2019-02-25 10:30:08', null);
INSERT INTO `permission` VALUES ('24', '请假', '0', '1600', '0', '请假', ' vacate', null, '/ vacate', '2019-02-25 10:36:54', null);
INSERT INTO `permission` VALUES ('25', '请假申请', '24', '1600', '0', '请假申请', 'vacate', null, '/vacate/apply', '2019-02-25 10:38:28', null);
INSERT INTO `permission` VALUES ('26', '请假查询', '24', '1600', '0', '请假查询', 'vacateselect', null, '/vacate/select', '2019-02-25 10:39:50', null);
INSERT INTO `permission` VALUES ('27', '请假撤销', '24', '1600', '0', '请假撤销', 'vacateexit', null, '/vacate/exit', '2019-02-25 10:40:37', null);
INSERT INTO `permission` VALUES ('28', '考勤', '0', '1600', '0', '考勤', ' attendance', null, '/attendance', '2019-02-25 10:42:36', null);
INSERT INTO `permission` VALUES ('29', '签到', '28', '1600', '0', '签到', 'signin', null, '/attendance/signin', '2019-02-25 10:45:58', null);
INSERT INTO `permission` VALUES ('30', '签退', '28', '1600', '0', '签退', 'signout', null, '/attendance/signout', '2019-02-25 10:46:01', null);
INSERT INTO `permission` VALUES ('31', '加班申请', '28', '1600', '0', '加班申请', 'extrawork', null, '/attendance/apply', '2019-02-25 10:46:04', null);
INSERT INTO `permission` VALUES ('32', '工作总结', '0', '1700', '0', '工作总结', 'worksummary', null, 'work/summary', '2019-02-25 10:47:53', null);
INSERT INTO `permission` VALUES ('33', '订餐', '0', '1700', '0', '订餐', 'order', null, '/order', '2019-02-25 10:48:43', null);
INSERT INTO `permission` VALUES ('35', '消息通知', '14', '1600', '0', '消息通知', 'messagesend', null, '/message/send', '2019-02-25 16:43:33', null);
INSERT INTO `permission` VALUES ('36', '发布通知', '14', '10001', '0', '发布通知', 'messagesend', null, '/message/send', '2019-02-27 20:46:01', null);
INSERT INTO `permission` VALUES ('37', '部门列表', '6', '4545', '0', '部门列表', 'deptmanage', null, '/dept/deptList', '2019-02-28 21:12:53', null);

-- ----------------------------
-- Table structure for `quarters`
-- ----------------------------
DROP TABLE IF EXISTS `quarters`;
CREATE TABLE `quarters` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  `deptno` int(10) NOT NULL,
  `introduce` varchar(200) NOT NULL DEFAULT '无岗位介绍',
  `version` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of quarters
-- ----------------------------
INSERT INTO `quarters` VALUES ('4', '开', '1', '无岗位介绍', '7');
INSERT INTO `quarters` VALUES ('5', '职位手动', '1', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('6', '撒的撒', '1', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('7', '第三方', '1', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('8', '(NUL阿斯顿发生L', '1', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('9', '阿斯顿发顺丰', '2', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('10', '阿斯顿发', '2', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('11', '固定', '2', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('12', '功夫大使馆', '2', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('13', '是大法官', '2', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('14', 'hhg', '2', '无岗位介绍', '1');
INSERT INTO `quarters` VALUES ('15', '岗位sss', '3', '我是新添加的', '0');
INSERT INTO `quarters` VALUES ('16', '岗位色诉讼', '4', '我是测试用的', '0');
INSERT INTO `quarters` VALUES ('17', '岗位少时诵诗书所', '4', '我还是测试的', '0');
INSERT INTO `quarters` VALUES ('18', '岗位llll', '3', '无岗位介绍', '0');
INSERT INTO `quarters` VALUES ('19', '我是添加', '5', '我是添加来的', '0');

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) DEFAULT NULL COMMENT '角色名称',
  `descpt` varchar(50) DEFAULT NULL COMMENT '角色描述',
  `code` varchar(20) DEFAULT NULL COMMENT '角色编号',
  `insert_uid` int(11) DEFAULT NULL COMMENT '操作用户id',
  `insert_time` datetime DEFAULT NULL COMMENT '添加数据时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', '超级管理', '超级管理员', 'superman', null, '2018-01-09 19:28:53', '2019-02-28 21:13:12');
INSERT INTO `role` VALUES ('2', '上级领导', '上级领导', 'highmanage', null, '2018-01-17 13:53:23', '2018-01-18 13:39:29');
INSERT INTO `role` VALUES ('3', '部门领导', '部门注入', 'deptmanage', null, '2018-01-18 13:41:47', '2018-04-22 21:15:38');
INSERT INTO `role` VALUES ('4', '员工', '员工', 'employee', null, '2018-01-18 14:03:00', '2018-04-22 21:15:59');
INSERT INTO `role` VALUES ('5', '维护员', '客维员', 'guestmanage', null, '2018-01-18 14:06:48', '2018-04-22 21:16:07');

-- ----------------------------
-- Table structure for `role_permission`
-- ----------------------------
DROP TABLE IF EXISTS `role_permission`;
CREATE TABLE `role_permission` (
  `permit_id` int(5) NOT NULL AUTO_INCREMENT,
  `role_id` int(5) NOT NULL,
  PRIMARY KEY (`permit_id`,`role_id`),
  KEY `perimitid` (`permit_id`) USING BTREE,
  KEY `roleid` (`role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of role_permission
-- ----------------------------
INSERT INTO `role_permission` VALUES ('1', '1');
INSERT INTO `role_permission` VALUES ('1', '2');
INSERT INTO `role_permission` VALUES ('2', '1');
INSERT INTO `role_permission` VALUES ('2', '2');
INSERT INTO `role_permission` VALUES ('3', '1');
INSERT INTO `role_permission` VALUES ('3', '2');
INSERT INTO `role_permission` VALUES ('4', '1');
INSERT INTO `role_permission` VALUES ('5', '1');
INSERT INTO `role_permission` VALUES ('5', '2');
INSERT INTO `role_permission` VALUES ('5', '3');
INSERT INTO `role_permission` VALUES ('5', '5');
INSERT INTO `role_permission` VALUES ('6', '1');
INSERT INTO `role_permission` VALUES ('6', '2');
INSERT INTO `role_permission` VALUES ('6', '3');
INSERT INTO `role_permission` VALUES ('6', '4');
INSERT INTO `role_permission` VALUES ('6', '5');
INSERT INTO `role_permission` VALUES ('8', '1');
INSERT INTO `role_permission` VALUES ('8', '2');
INSERT INTO `role_permission` VALUES ('8', '3');
INSERT INTO `role_permission` VALUES ('8', '5');
INSERT INTO `role_permission` VALUES ('10', '1');
INSERT INTO `role_permission` VALUES ('10', '2');
INSERT INTO `role_permission` VALUES ('10', '3');
INSERT INTO `role_permission` VALUES ('10', '4');
INSERT INTO `role_permission` VALUES ('11', '1');
INSERT INTO `role_permission` VALUES ('11', '2');
INSERT INTO `role_permission` VALUES ('11', '3');
INSERT INTO `role_permission` VALUES ('11', '5');
INSERT INTO `role_permission` VALUES ('12', '2');
INSERT INTO `role_permission` VALUES ('12', '3');
INSERT INTO `role_permission` VALUES ('13', '1');
INSERT INTO `role_permission` VALUES ('13', '2');
INSERT INTO `role_permission` VALUES ('13', '3');
INSERT INTO `role_permission` VALUES ('13', '5');
INSERT INTO `role_permission` VALUES ('14', '1');
INSERT INTO `role_permission` VALUES ('14', '2');
INSERT INTO `role_permission` VALUES ('14', '3');
INSERT INTO `role_permission` VALUES ('14', '5');
INSERT INTO `role_permission` VALUES ('15', '1');
INSERT INTO `role_permission` VALUES ('16', '1');
INSERT INTO `role_permission` VALUES ('17', '1');
INSERT INTO `role_permission` VALUES ('18', '1');
INSERT INTO `role_permission` VALUES ('19', '1');
INSERT INTO `role_permission` VALUES ('20', '1');
INSERT INTO `role_permission` VALUES ('21', '1');
INSERT INTO `role_permission` VALUES ('22', '1');
INSERT INTO `role_permission` VALUES ('23', '1');
INSERT INTO `role_permission` VALUES ('24', '1');
INSERT INTO `role_permission` VALUES ('25', '1');
INSERT INTO `role_permission` VALUES ('26', '1');
INSERT INTO `role_permission` VALUES ('27', '1');
INSERT INTO `role_permission` VALUES ('28', '1');
INSERT INTO `role_permission` VALUES ('29', '1');
INSERT INTO `role_permission` VALUES ('30', '1');
INSERT INTO `role_permission` VALUES ('31', '1');
INSERT INTO `role_permission` VALUES ('32', '1');
INSERT INTO `role_permission` VALUES ('33', '1');
INSERT INTO `role_permission` VALUES ('35', '1');
INSERT INTO `role_permission` VALUES ('36', '1');
INSERT INTO `role_permission` VALUES ('37', '1');

-- ----------------------------
-- Table structure for `tbl_flow`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_flow`;
CREATE TABLE `tbl_flow` (
  `flow_id` int(50) NOT NULL AUTO_INCREMENT,
  `flow_name` varchar(500) DEFAULT NULL COMMENT '流程名称',
  `remark` varchar(500) DEFAULT '' COMMENT '备注',
  `flow_no` int(50) NOT NULL COMMENT '流程号',
  PRIMARY KEY (`flow_id`),
  KEY `flow_no` (`flow_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_flow
-- ----------------------------
INSERT INTO `tbl_flow` VALUES ('1', '请假流程', '请假流程', '5');
INSERT INTO `tbl_flow` VALUES ('2', '报销流程', '报销流程', '10');

-- ----------------------------
-- Table structure for `tbl_flow_line`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_flow_line`;
CREATE TABLE `tbl_flow_line` (
  `flow_line_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '流程线编号',
  `flow_no` int(20) NOT NULL COMMENT '流程号',
  `prev_node_id` int(20) DEFAULT NULL COMMENT '前一节点编号',
  `next_node_id` int(20) DEFAULT NULL COMMENT '后一节点编号',
  `remark` varchar(20) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`flow_line_id`),
  KEY `no` (`flow_no`),
  KEY `pno` (`prev_node_id`),
  KEY `ano` (`next_node_id`),
  CONSTRAINT `ano` FOREIGN KEY (`next_node_id`) REFERENCES `tbl_flow_node` (`flow_node_id`),
  CONSTRAINT `no` FOREIGN KEY (`flow_no`) REFERENCES `tbl_flow` (`flow_no`),
  CONSTRAINT `pno` FOREIGN KEY (`prev_node_id`) REFERENCES `tbl_flow_node` (`flow_node_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_flow_line
-- ----------------------------
INSERT INTO `tbl_flow_line` VALUES ('1', '5', '1', '2', '提交项目经理审批');
INSERT INTO `tbl_flow_line` VALUES ('2', '5', '2', '3', '提交总经理审批');

-- ----------------------------
-- Table structure for `tbl_flow_node`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_flow_node`;
CREATE TABLE `tbl_flow_node` (
  `flow_node_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '流程节点编号',
  `flow_no` int(20) NOT NULL COMMENT '流程号 与流程表对应',
  `flow_node_name` varchar(100) DEFAULT NULL COMMENT '流程节点名称',
  `flow_node_role` varchar(100) DEFAULT NULL COMMENT '流程角色',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`flow_node_id`),
  KEY `flono` (`flow_no`),
  CONSTRAINT `flono` FOREIGN KEY (`flow_no`) REFERENCES `tbl_flow` (`flow_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_flow_node
-- ----------------------------
INSERT INTO `tbl_flow_node` VALUES ('1', '5', '提交请假单', '无', '提交请假单');
INSERT INTO `tbl_flow_node` VALUES ('2', '5', '项目经理审批', '项目经理', '项目经理审批');
INSERT INTO `tbl_flow_node` VALUES ('3', '5', '总经理审批', '总经理', '总经理');

-- ----------------------------
-- Table structure for `tbl_flow_role_user`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_flow_role_user`;
CREATE TABLE `tbl_flow_role_user` (
  `flow_role_name` varchar(100) NOT NULL COMMENT '流程角色名称',
  `user_id` int(20) NOT NULL COMMENT '用户id',
  `dept_no` int(20) NOT NULL COMMENT '部门编号',
  PRIMARY KEY (`user_id`),
  KEY `gg` (`dept_no`),
  CONSTRAINT `qq` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_flow_role_user
-- ----------------------------
INSERT INTO `tbl_flow_role_user` VALUES ('总经理', '3', '4');
INSERT INTO `tbl_flow_role_user` VALUES ('项目经理', '5', '4');

-- ----------------------------
-- Table structure for `tbl_leave_audit`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_leave_audit`;
CREATE TABLE `tbl_leave_audit` (
  `id` int(10) NOT NULL COMMENT '审批编号',
  `leave_id` varchar(50) DEFAULT NULL COMMENT '请假编号 与请假表对应',
  `flow_node_id` int(10) DEFAULT NULL COMMENT '节点编号',
  `user_id` int(10) DEFAULT NULL COMMENT '审批人编号',
  `user_name` varchar(20) DEFAULT NULL COMMENT '审批人姓名',
  `audit_info` varchar(100) DEFAULT NULL COMMENT '审批意见',
  `audit_date` datetime DEFAULT NULL COMMENT '审批日期',
  PRIMARY KEY (`id`),
  KEY `ll` (`leave_id`),
  KEY `tt` (`flow_node_id`),
  KEY `t` (`user_id`),
  CONSTRAINT `t` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `tt` FOREIGN KEY (`flow_node_id`) REFERENCES `tbl_flow_node` (`flow_node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_leave_audit
-- ----------------------------
INSERT INTO `tbl_leave_audit` VALUES ('1', '1', '2', '5', '王五', '同意', '2019-02-26 11:25:46');
INSERT INTO `tbl_leave_audit` VALUES ('2', '2', '3', '3', '张三', '同意', '2019-02-28 11:33:15');

-- ----------------------------
-- Table structure for `tbl_user`
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT '' COMMENT '用户名',
  `mobile` varchar(15) DEFAULT '' COMMENT '手机号',
  `email` varchar(50) DEFAULT '' COMMENT '邮箱',
  `password` varchar(50) DEFAULT '' COMMENT '密码',
  `insert_uid` int(11) DEFAULT NULL COMMENT '添加该用户的用户id',
  `insert_time` datetime DEFAULT NULL COMMENT '注册时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除（0：正常；1：已删）',
  `is_job` tinyint(1) DEFAULT '0' COMMENT '是否在职（0：正常；1，离职）',
  `mcode` varchar(10) DEFAULT '' COMMENT '短信验证码',
  `send_time` datetime DEFAULT NULL COMMENT '短信发送时间',
  `version` int(10) DEFAULT '0' COMMENT '更新版本',
  `deptno` int(10) NOT NULL COMMENT '部门编号',
  PRIMARY KEY (`id`),
  KEY `deptno` (`deptno`),
  KEY `name` (`username`) USING BTREE,
  KEY `id` (`id`) USING BTREE,
  KEY `mobile` (`mobile`) USING BTREE,
  KEY `id_2` (`id`,`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户表';

-- ----------------------------
-- Records of tbl_user
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT '' COMMENT '用户名',
  `mobile` varchar(15) DEFAULT '' COMMENT '手机号',
  `email` varchar(50) DEFAULT '' COMMENT '邮箱',
  `password` varchar(50) DEFAULT '' COMMENT '密码',
  `insert_uid` int(11) DEFAULT NULL COMMENT '添加该用户的用户id',
  `insert_time` datetime DEFAULT NULL COMMENT '注册时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除（0：正常；1：已删）',
  `is_job` tinyint(1) DEFAULT '0' COMMENT '是否在职（0：正常；1，离职）',
  `mcode` varchar(10) DEFAULT '' COMMENT '短信验证码',
  `send_time` datetime DEFAULT NULL COMMENT '短信发送时间',
  `version` int(10) DEFAULT '0' COMMENT '更新版本',
  `dno` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`username`) USING BTREE,
  KEY `id` (`id`) USING BTREE,
  KEY `mobile` (`mobile`) USING BTREE,
  KEY `id_2` (`id`,`username`),
  KEY `ds` (`dno`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='用户表';

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'wyait', '15035344074', 'aaa', 'c33367701511b4f6020ec61ded352059', null, '2017-12-29 17:27:23', '2018-01-09 13:34:33', '0', '0', '', '2019-02-27 16:08:48', '39', null);
INSERT INTO `user` VALUES ('3', '张三', '11155556667', 'a11', 'c33367701511b4f6020ec61ded352059', '1', '2018-01-01 15:17:19', '2018-04-22 21:14:58', '0', '0', null, null, '0', '4');
INSERT INTO `user` VALUES ('5', '王五', '11155552233', 'a', 'c33367701511b4f6020ec61ded352059', null, '2018-01-02 13:41:29', '2018-01-10 15:55:37', '0', '1', null, null, '0', '4');
INSERT INTO `user` VALUES ('6', '网六', '12356456542', 'afdfd123', 'c33367701511b4f6020ec61ded352059', null, '2018-01-02 13:44:04', '2018-01-02 16:56:05', '0', '1', null, null, '0', '4');
INSERT INTO `user` VALUES ('7', '马六', '11155623232', '123456', 'c33367701511b4f6020ec61ded352059', null, '2018-01-02 13:44:23', null, '1', '0', null, null, '0', '4');
INSERT INTO `user` VALUES ('8', 'manage', '12345678911', '359818226@.com', 'e10adc3949ba59abbe56e057f20f883e', null, '2018-01-04 16:51:21', '2018-01-08 21:02:38', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('10', 'b', '12345678977', 'a', 'c33367701511b4f6020ec61ded352059', '1', '2018-01-09 10:30:56', '2018-04-22 21:27:53', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('11', 'e', '12345678911', 'e', 'c33367701511b4f6020ec61ded352059', null, '2018-01-09 10:31:08', null, '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('12', 'ee', '12345678919', 'a', 'c33367701511b4f6020ec61ded352059', '1', '2018-01-09 10:31:33', '2018-04-22 21:28:01', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('13', '456', '12345678888', 'e', 'c33367701511b4f6020ec61ded352059', null, '2018-01-09 10:31:46', null, '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('14', '89', '12345612222', 'a', 'c33367701511b4f6020ec61ded352059', null, '2018-01-09 10:31:58', null, '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('15', 'aa', '12345678915', 'ee1', 'c33367701511b4f6020ec61ded352059', null, '2018-01-09 10:32:12', '2018-01-09 13:29:12', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('16', 'tty', '12345678521', 'aa', 'c33367701511b4f6020ec61ded352059', null, '2018-01-09 13:32:17', '2018-01-09 13:45:58', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('17', 'oo', '12345666666', 'qq', 'c33367701511b4f6020ec61ded352059', '1', '2018-01-09 13:51:01', '2018-04-24 19:30:01', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('18', 'iik', '12345678920', 'aaaa120', 'c33367701511b4f6020ec61ded352059', null, '2018-01-09 16:31:03', '2018-01-09 16:41:28', '0', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('19', '123456', '12321727724', '24319@qq.com', 'c33367701511b4f6020ec61ded352059', '1', '2018-01-17 09:24:27', '2018-04-28 19:21:59', '0', '0', '386614', '2018-01-18 09:45:41', '0', null);
INSERT INTO `user` VALUES ('20', 'xiaoqiabng1', '11111111212', '1213@qq.com', 'c33367701511b4f6020ec61ded352059', '19', '2018-01-17 13:54:08', '2018-04-26 14:09:23', '0', '0', '353427', '2018-01-17 13:56:59', '0', null);
INSERT INTO `user` VALUES ('21', 'aaaacc2', '10123235656', '', 'c33367701511b4f6020ec61ded352059', '1', '2018-04-22 21:14:48', '2018-05-02 16:55:12', '0', '0', null, null, '8', null);
INSERT INTO `user` VALUES ('22', '11232323232', '23233223322', '', 'c33367701511b4f6020ec61ded352059', '19', '2018-04-26 13:30:44', '2018-04-28 19:22:11', '1', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('23', 'bbb1', '10222224564', '', 'c33367701511b4f6020ec61ded352059', '19', '2018-04-26 14:36:30', '2018-04-28 15:43:21', '1', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('24', 'eee', '12536369898', '', 'c33367701511b4f6020ec61ded352059', '19', '2018-04-26 18:37:34', '2018-04-28 15:36:12', '1', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('25', 'fast', '12312312312', '', 'c33367701511b4f6020ec61ded352059', '1', '2018-04-28 09:37:32', '2018-04-28 09:37:48', '1', '0', null, null, '0', null);
INSERT INTO `user` VALUES ('26', 'xxx', '12923235959', '', 'c33367701511b4f6020ec61ded352059', '1', '2018-05-02 16:55:35', '2018-05-02 19:35:51', '1', '0', null, null, '5', null);
INSERT INTO `user` VALUES ('27', 'ppp12', '12826265353', '', 'c33367701511b4f6020ec61ded352059', '1', '2018-05-02 16:56:41', '2018-05-02 19:30:05', '1', '0', null, null, '19', null);
INSERT INTO `user` VALUES ('28', 'admin', '13633585056', '1579787224@qq.com', '1112', '1', '2019-02-15 12:50:55', '2019-02-07 12:51:01', '0', '0', '', null, '0', null);
INSERT INTO `user` VALUES ('29', 'dfdfdfdfdfdfd', '1112', '157@qq.com', '20d135f0f28185b84a4cf7aa51f29500', '1', '2019-02-26 16:46:29', '2019-02-27 16:50:54', '0', '0', null, null, '2', null);

-- ----------------------------
-- Table structure for `user_role`
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(5) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `userid` (`user_id`) USING BTREE,
  KEY `roleid` (`role_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('1', '1');
INSERT INTO `user_role` VALUES ('3', '5');
INSERT INTO `user_role` VALUES ('12', '5');
INSERT INTO `user_role` VALUES ('19', '3');
INSERT INTO `user_role` VALUES ('20', '2');
INSERT INTO `user_role` VALUES ('21', '4');
INSERT INTO `user_role` VALUES ('22', '5');
INSERT INTO `user_role` VALUES ('23', '3');
INSERT INTO `user_role` VALUES ('24', '5');
INSERT INTO `user_role` VALUES ('25', '2');
INSERT INTO `user_role` VALUES ('26', '5');
INSERT INTO `user_role` VALUES ('27', '5');
INSERT INTO `user_role` VALUES ('29', '4');

-- ----------------------------
-- Table structure for `vacate`
-- ----------------------------
DROP TABLE IF EXISTS `vacate`;
CREATE TABLE `vacate` (
  `name` varchar(20) NOT NULL COMMENT '请假人姓名',
  `type` varchar(20) NOT NULL COMMENT '请假类型',
  `reason` varchar(20) DEFAULT NULL COMMENT '请假原因',
  `starttime` varchar(20) DEFAULT NULL COMMENT '开始日期',
  `endtime` varchar(20) DEFAULT NULL COMMENT '结束日期',
  `tel` varchar(20) DEFAULT NULL,
  `status` int(20) DEFAULT '0' COMMENT '请假单状态  0表示草稿  1表示已经提交审批 2表示审批结束',
  `flow_no` int(20) NOT NULL DEFAULT '5' COMMENT '流程号',
  `current_node` int(20) NOT NULL DEFAULT '1' COMMENT '当前节点编号',
  `add_date` varchar(20) NOT NULL COMMENT '提交请假单时间',
  `id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ming` (`name`),
  KEY `oo` (`flow_no`),
  KEY `nn` (`current_node`),
  KEY `id` (`type`),
  KEY `type` (`type`),
  CONSTRAINT `ming` FOREIGN KEY (`name`) REFERENCES `user` (`username`),
  CONSTRAINT `nn` FOREIGN KEY (`current_node`) REFERENCES `tbl_flow_node` (`flow_node_id`),
  CONSTRAINT `oo` FOREIGN KEY (`flow_no`) REFERENCES `tbl_flow` (`flow_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of vacate
-- ----------------------------
INSERT INTO `vacate` VALUES ('wyait', '婚假', 'klkl', '2019-02-12', '2019-02-14', '13633585056', '1', '5', '2', '2019-02-28 10:42:52', '0f2e2c8bbf2f47bf8c29ea5b58bf75cf');
INSERT INTO `vacate` VALUES ('wyait', '婚假', 'dsadaa', '2019-02-14', '2019-02-15', '13633585056', '1', '5', '2', '2019-02-28 13:06:22', '10c39be85b6c42fda2abbd7aaab949d6');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'fgjdrsus', '2019-02-05', '2019-02-06', '13633585056', '1', '5', '2', '2019-02-28 13:12:16', '1c21c5aaf7e543299bf264f01dfd56b6');
INSERT INTO `vacate` VALUES ('wyait', '事假', '事务', '2019-02-08', '2019-02-11', '15888888888', '1', '5', '2', '2019-02-28 12:48:07', '267e3dfe878f412f84e7d817c60d8ec9');
INSERT INTO `vacate` VALUES ('wyait', '婚假', '颠三倒四多', '2019-02-05', '2019-02-08', '13633585056', '1', '5', '2', '2019-02-28 12:57:20', '33b79a60bdc54257bf3c0ce5642fe37a');
INSERT INTO `vacate` VALUES ('wyait', '事假', '45454454', '2019-02-12', '2019-02-07', '13633585056', '1', '5', '2', '2019-02-28 13:08:03', '34d644d60c8b4546be9983feb5d83519');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'jijijiji', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 12:59:59', '381007edfd524752aeaa30fe66781e2c');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'zssasd', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 13:02:08', '3e036c9b4e0445b7b5505e9227dd5183');
INSERT INTO `vacate` VALUES ('wyait', '事假', '454545', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 10:54:23', '48d80e2ef7de4730bb5c66567f4fe3d9');
INSERT INTO `vacate` VALUES ('wyait', '婚假', '45454545', '2019-02-13', '2019-02-12', '13633585056', '1', '5', '2', '2019-02-28 13:22:40', '57b11a4ed10b4d2dbbd0939b1e4cf3f1');
INSERT INTO `vacate` VALUES ('wyait', '婚假', 'klkl', '2019-02-12', '2019-02-14', '13633585056', '1', '5', '2', '2019-02-28 10:42:52', '61cb5502185343a7962dffc0009a8752');
INSERT INTO `vacate` VALUES ('wyait', '婚假', '哈哈哈啊哈', '2019-02-07', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 12:50:11', '62ccbc7da40d4f02b18278b4e05f1c56');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'jijijiji', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 12:59:59', '63c8bfcb642a476b99ce9314d8c5fe3f');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'zssasd', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 13:02:08', '65a24e70a82c40caaeaa2c0707611f07');
INSERT INTO `vacate` VALUES ('wyait', '婚假', 'kl', '2019-02-04', '2019-02-07', '13633585056', '1', '5', '2', '2019-02-28 10:37:39', '6918b22f5a5c4434a0453ba3503c6637');
INSERT INTO `vacate` VALUES ('wyait', '产假', '我要', '2019-02-13', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 12:55:14', '6d30e6cdacaa453a8d8cd0be57fa9bf4');
INSERT INTO `vacate` VALUES ('wyait', '婚假', '颠三倒四多', '2019-02-05', '2019-02-08', '13633585056', '1', '5', '2', '2019-02-28 12:57:20', '778759c54876487cb372a122d4d5313e');
INSERT INTO `vacate` VALUES ('wyait', '产假', '我要', '2019-02-13', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 12:55:14', '7ec072860a9244128a924076531d6e47');
INSERT INTO `vacate` VALUES ('wyait', '事假', '我要请假', '2019-02-12', '2019-02-05', '15888777777', '1', '5', '2', '2019-02-28 10:34:18', '8416935cb4b74289807767d3765d29cd');
INSERT INTO `vacate` VALUES ('wyait', '病假', '11111111111', '2019-02-20', '2019-02-21', '13655557777', '1', '5', '2', '2019-02-28 13:18:57', '8751c5408398432fa5f71957cde5bc5b');
INSERT INTO `vacate` VALUES ('wyait', '婚假', 'kl', '2019-02-04', '2019-02-07', '13633585056', '1', '5', '2', '2019-02-28 10:37:39', '89e21e202e464c6e845b86f6f310b397');
INSERT INTO `vacate` VALUES ('wyait', '事假', '222222', '2019-02-11', '2019-02-19', '13633585056', '1', '5', '2', '2019-02-28 13:24:19', '8b4b706e8d184945b76d20d2e1f1c6e1');
INSERT INTO `vacate` VALUES ('wyait', '事假', '我要请假', '2019-02-12', '2019-02-05', '15888777777', '1', '5', '2', '2019-02-28 10:34:18', '93bf6e627e7a43d5afd4d2e55a47c2b8');
INSERT INTO `vacate` VALUES ('wyait', '婚假', 'dsadaa', '2019-02-14', '2019-02-15', '13633585056', '1', '5', '2', '2019-02-28 13:06:22', 'a4ae2f8ceda44dada8c0a093008d05cc');
INSERT INTO `vacate` VALUES ('wyait', '事假', '454545', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 10:54:23', 'a4b8d638ea90470e847db8824344f917');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'jijijiji', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 13:00:37', 'aaa23c734ba94ad887f4c94a240041e8');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'jijijiji', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 13:00:37', 'aaeead6d4b2e421db66b583044649104');
INSERT INTO `vacate` VALUES ('wyait', '婚假', '45454545', '2019-02-13', '2019-02-12', '13633585056', '1', '5', '2', '2019-02-28 13:22:40', 'bf29fed862b7496094c3ea94900ed6b2');
INSERT INTO `vacate` VALUES ('wyait', '事假', '我要吃饭', '2019-02-12', '2019-02-05', '15888777777', '1', '5', '2', '2019-02-28 10:35:55', 'c060793e20ea4017846c34bd812840c3');
INSERT INTO `vacate` VALUES ('wyait', '病假', '11111111111', '2019-02-20', '2019-02-21', '13655557777', '1', '5', '2', '2019-02-28 13:18:57', 'caada66f1c6548fcb6b4dbe743cbb88c');
INSERT INTO `vacate` VALUES ('wyait', '事假', '事务', '2019-02-08', '2019-02-11', '15888888888', '1', '5', '2', '2019-02-28 12:48:07', 'caf629e00b0641efa1f3b002cfa2dded');
INSERT INTO `vacate` VALUES ('wyait', '婚假', '哈哈哈啊哈', '2019-02-07', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 12:50:11', 'cc1de024ebbd4a63a3af20ede80017cf');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'fgjdrsus', '2019-02-05', '2019-02-06', '13633585056', '1', '5', '2', '2019-02-28 13:12:16', 'd74e8876902c4de4b7af4cb304d20f2b');
INSERT INTO `vacate` VALUES ('wyait', '病假', '我呀欧青', '2019-02-12', '2019-02-20', '13633585056', '1', '5', '2', '2019-02-28 12:53:30', 'd91b0ba7b3dd4c06aeaedf6ba04c03aa');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'jijijiji', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 13:01:12', 'e53c70362d2f4146985cb54c67fb533f');
INSERT INTO `vacate` VALUES ('wyait', '事假', 'jijijiji', '2019-02-12', '2019-02-13', '13633585056', '1', '5', '2', '2019-02-28 13:01:12', 'eb2e786644dc45a8b84b42c09ffa88b0');
INSERT INTO `vacate` VALUES ('wyait', '事假', '我要吃饭', '2019-02-12', '2019-02-05', '15888777777', '1', '5', '2', '2019-02-28 10:35:55', 'ebdfa0be121c41f2b87dadf20973a1c0');
INSERT INTO `vacate` VALUES ('wyait', '病假', '我呀欧青', '2019-02-12', '2019-02-20', '13633585056', '1', '5', '2', '2019-02-28 12:53:30', 'f3788aee40024614a54230f60e414a72');
INSERT INTO `vacate` VALUES ('wyait', '事假', '45454454', '2019-02-12', '2019-02-07', '13633585056', '1', '5', '2', '2019-02-28 13:08:03', 'f392e0c3922a40bba3bdf8135ccec2a5');

-- ----------------------------
-- Table structure for `worklog`
-- ----------------------------
DROP TABLE IF EXISTS `worklog`;
CREATE TABLE `worklog` (
  `id` int(10) NOT NULL,
  `userId` int(10) NOT NULL,
  `starttime` date DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`userId`),
  CONSTRAINT `uid` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of worklog
-- ----------------------------
