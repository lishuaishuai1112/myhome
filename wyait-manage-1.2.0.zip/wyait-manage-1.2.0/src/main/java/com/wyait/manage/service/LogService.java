package com.wyait.manage.service;

import java.util.List;

import com.wyait.manage.entity.Log;
import com.wyait.manage.pojo.PageObject;

public interface LogService {
	
	 /**
	  * 执行删除操作
	  * @param ids 日志记录的id
	  * @return
	  */
	 int deleteObjects(Integer... ids);
	
     /**
      * 
  * 依据条件分页查询日志信息
      * @param username 用户名
      * @param pageCurrent 当前页码
      * @return 对查询结果的封装
      */
	 PageObject<Log> findPageObjects(
             String username,
             Integer pageCurrent);

	List<Log> getLogList();
}





