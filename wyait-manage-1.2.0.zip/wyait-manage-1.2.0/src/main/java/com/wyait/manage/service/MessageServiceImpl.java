package com.wyait.manage.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wyait.manage.dao.MessageMapper;
import com.wyait.manage.pojo.Message;
import com.wyait.manage.utils.PageDataResult;


/**
 * 通知功能的service层实现
 * @author 谢洪涛
 *
 */

@Service
public class MessageServiceImpl implements MessageService{

	@Autowired
	private MessageMapper messageMapper;
	
	public int saveMessage(Message message) {
		message.setTime(new Date());
		return messageMapper.saveMessage(message);
	}


	@Override
	public PageDataResult getMessage(Integer start, Integer limit) {
		List<Message> messages = messageMapper.queryMessage(start , limit);
		PageDataResult pdr = new PageDataResult();
		int totals = messageMapper.queryAll();
		pdr.setList(messages);
		pdr.setTotals(totals);
		return pdr;
	}

	



		
}
