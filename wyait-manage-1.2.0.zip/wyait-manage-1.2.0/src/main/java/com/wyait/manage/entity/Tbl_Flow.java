package com.wyait.manage.entity;

/**
 * @Auther: tedu
 * @Date: 2019/2/26 18:35
 * @Description:请假流程
 */
public class Tbl_Flow {
    //流程编号
    private int flowId;
//流程名称
    private String flowName;
    //流程号
private Integer flowNo;

    public Integer getFlowNo() {
        return flowNo;
    }

    public void setFlowNo(Integer flowNo) {
        this.flowNo = flowNo;
    }

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    public int getFlowId() {
        return flowId;
    }

    public void setFlowId(int flowId) {
        this.flowId = flowId;
    }
}
