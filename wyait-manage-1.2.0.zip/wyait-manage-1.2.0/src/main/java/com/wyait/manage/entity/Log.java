package com.wyait.manage.entity;

import java.io.Serializable;
import java.util.Date;

public class Log implements Serializable{
	private static final long serialVersionUID = -4523256868571326166L;
	private Integer id;
	/**操作用户*/
	private String userName;
	/**执行的操作*/
	private String result;
	/**执行这个操作对应的方法*/
	private String ip;
	/**方法的执行时间*/
	private Date time;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
