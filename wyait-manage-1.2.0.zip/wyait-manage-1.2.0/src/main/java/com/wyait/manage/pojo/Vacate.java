package com.wyait.manage.pojo;


import java.io.Serializable;

import static jdk.nashorn.internal.objects.NativeString.trim;


/**
 * @实体名称
 * @数表名称 VACATE
 * @开发日期 2019-02-25
 * @技术服务 www.fwjava.com
 */
public class Vacate implements Serializable {

    /**
     * 请假编号(必填项)(主键ID)
     */
    private String id;
    /**
     * 请假人姓名(必填项)
     */
    private String name;
    /**
     * (必填项)
     */

    /**
     * 请假类型(必填项)
     */
    private String type;
    /**
     * 请假原因
     */
    private String reason;
    /**
     * 开始日期
     */
    private String starttime;
    /**
     * 结束日期
     */
    private String endtime;
    /**
     *
     */
    private String tel;
    /**
     *
     */

    /**
     * 请假单状态0表示草稿1表示已经提交审批2表示审批结束
     */
    private Integer status;
    /**
     * 流程号(必填项)
     */
    private Integer flowNo;
    /**
     * 当前节点编号(必填项)
     */
    private Integer currentNode;
    //添加时间
    private String addDate;

    public void setCurrentNode(Integer currentNode) {
        this.currentNode = currentNode;
    }

    public String getAddDate() {
        return addDate;
    }

    public void setAddDate(String addDate) {
        this.addDate = addDate;
    }
    /*
     *--------------------------------------------------
     * Getter方法区
     *--------------------------------------------------
     */

    /**
     * 请假编号(必填项)(主键ID)
     */
    public String getId() {
        return id;
    }

    /**
     * 请假人姓名(必填项)
     */
    public String getName() {
        return trim(name);
    }

    /**
     * 请假类型(必填项)
     */
    public String getType() {
        return trim(type);
    }

    /**
     * 请假原因
     */
    public String getReason() {
        return trim(reason);
    }

    /**
     * 开始日期
     */
    public String getStarttime() {
        return starttime;
    }

    /**
     * 结束日期
     */
    public String getEndtime() {
        return endtime;
    }

    /**
     *
     */
    public String getTel() {
        return trim(tel);
    }

    /**
     *
     */


    /**
     * 请假单状态0表示草稿1表示已经提交审批2表示审批结束
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 流程号(必填项)
     */
    public Integer getFlowNo() {
        return flowNo;
    }

    /**
     * 当前节点编号(必填项)
     */
    public Integer getCurrentNode() {
        return currentNode;
    }

    /**
     * 请假编号(必填项)(主键ID)
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 请假人姓名(必填项)
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * (必填项)
     */
    /**
     * 请假类型(必填项)
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 请假原因
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    /**
     * 开始日期
     */
    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    /**
     * 结束日期
     */
    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    /**
     *
     */
    public void setTel(String tel) {
        this.tel = tel;
    }

    @Override
    public String toString() {
        return "Vacate{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ",type='" + type + '\'' +
                ", reason='" + reason + '\'' +
                ", starttime='" + starttime + '\'' +
                ", endtime='" + endtime + '\'' +
                ", tel='" + tel + '\'' +
                ", status=" + status +
                ", flowNo=" + flowNo +
                ", currentNode=" + currentNode +
                ", addDate=" + addDate +
                '}';
    }

    /**
     *
     */
    /**
     * 请假单状态0表示草稿1表示已经提交审批2表示审批结束
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 流程号(必填项)
     */
    public void setFlowNo(Integer flowNo) {
        this.flowNo = flowNo;
    }


}








    