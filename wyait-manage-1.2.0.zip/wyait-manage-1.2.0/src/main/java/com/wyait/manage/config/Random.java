package com.wyait.manage.config;

import java.util.Date;

/**
 * @Auther: tedu
 * @Date: 2019/2/28 09:47
 * @Description:
 */
public class Random {
   /*
    private static Long randomNumber;
    private static Long curIndex = Long.valueOf(0L);
    public synchronized static Long getId() throws Exception {
        Long index = null;
        // 从0到999 curIndex*100 curIndex 100-99900
        index = (curIndex = curIndex.longValue() + 1L).longValue() % 1000L;
        if (curIndex.longValue() >= 1000L) {
            curIndex = 0L;
        }
        //155131871448400158
        // 随机数 1-10
        randomNumber = Long.valueOf(new java.util.Random().nextInt(100));
        return (new Date()).getTime() * 100000L + index.longValue() * 100L
                + randomNumber.longValue();
    }
*/
public static void main(String[]args){
    long nowDate = new Date().getTime();
    System.out.println(nowDate);
}

}
