package com.wyait.manage.web.controller.log;

import org.springframework.web.bind.annotation.RequestMapping;

public class PageController {
@RequestMapping("doPageUI")
public String doPageUI(){
	return "common/page";
}
}
