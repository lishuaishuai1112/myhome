package com.wyait.manage.dao;

import com.wyait.manage.entity.DeptRoleDTO;
import com.wyait.manage.entity.DeptRolesVO;
import com.wyait.manage.entity.DeptSearchDTO;
import com.wyait.manage.pojo.Dept;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DeptMapper {

	List<Dept> deptList(@Param("start") Integer start, @Param("limit") Integer limit);

	int deptDelete(int id);

	int deptUpdate(Dept dept);

	int deptInsert(Dept dept);

	List<DeptRoleDTO> getdept(@Param("deptSearch") DeptSearchDTO deptSearch);

	Dept selectByPrimaryKey(Integer id);

	int setDeldept(Integer id);

	Dept finddeptByname(String name);

	void updateByPrimaryKeySelective(Dept dept);

	void insert(Dept dept);

	DeptRolesVO getdeptAndRoles(Integer id);


}