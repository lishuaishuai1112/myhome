package com.wyait.manage.utils;

import com.github.qcloudsms.SmsSingleSender;
import com.github.qcloudsms.SmsSingleSenderResult;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 发送短信验证码
 */
public class SendMsgServer {

	private static final Logger logger = LoggerFactory
			.getLogger(SendMsgServer.class);

	/**
	 * 
	 * @描述：(公共)发送短消息:
	 * @创建人：
	 * @创建时间：2016年7月22日 上午10:33:20
	 * @param phone 发送的号码
	 * @param   num 验证码
	 * @return  发送成功返回:ok，发送失败返回:no
	 */
	public static String SendMsg(String phone,String num) throws Exception {

		// 短信应用SDK AppID
		// 1400开头
		int appId = 1400187022;

		// 短信应用SDK AppKey
		String appKey = "2ec8c16df3540abd6cf45751cf5445ab";

		// 需要发送短信的手机号码
		// String[] phoneNumbers = {"15212111830"};

		// 短信模板ID，需要在短信应用中申请
		//NOTE: 这里的模板ID`7839`只是一个示例，真实的模板ID需要在短信控制台中申请
		int templateId = 283627;

		// 签名
		// NOTE: 这里的签名"腾讯云"只是一个示例，真实的签名需要在短信控制台中申请，另外签名参数使用的是`签名内容`，而不是`签名ID`
		String smsSign = "小帅帅的java人生";
// 需要发送短信的手机号码
		// String[] phoneNumbers = {"13954797835", "12345678902", "12345678903"};
		SmsSingleSender sSender = new SmsSingleSender(appId, appKey);
		//第一个参数0表示普通短信,1表示营销短信
		String[] params = {num,"1"};//参数，验证码为5678，60秒内填写
		SmsSingleSenderResult result = sSender.sendWithParam("86", phone,
				templateId, params, smsSign, "", "");  // 签名参数未提供或者为空时，会使用默认签名发送短信
		if (result.result != 0) {
			return "no";
		}
		else{
			return "ok";
		}
	}

}
