package com.wyait.manage.web.controller.log;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wyait.manage.entity.Log;
import com.wyait.manage.service.AuthService;
import com.wyait.manage.service.LogService;




@Controller
@RequestMapping("log")
public class LogController {
	@Autowired
	private LogService logService;
	//打印该类的日志信息
	/*@Autowired
	private static final Logger logger = LoggerFactory
			.getLogger(UserController.class);
	@RequestMapping("/login")
	public ModelAndView toLog(){
		System.out.println("Dsdsd");
		return  new ModelAndView("log/login");
	}*/
	@Autowired
	private AuthService AuthService;
	@RequestMapping("/login")
	public String doLogListUI(){
		System.out.println("sdsd");
		return "log/logg";
	}
	@RequestMapping("/getLogList")
	@ResponseBody
	public List<Log> getLogList(){
		List<Log> logList=logService.getLogList();
		System.out.println("112332435");
		return logList;
	}
	
}
