package com.wyait.manage.service;

import com.wyait.manage.pojo.Vacate;

import java.util.List;

/**
 * @Auther: tedu
 * @Date: 2019/2/28 13:43
 * @Description:
 */
public interface ApprovalService {
    List<Vacate> getAllVacate();
}
