package com.wyait.manage.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wyait.manage.dao.LogDao;
import com.wyait.manage.entity.Log;
import com.wyait.manage.exception.ServiceException;
import com.wyait.manage.pojo.PageObject;
@Service
public class LogServiceImpl implements LogService {
	@Autowired
	private LogDao LogDao;
	
	@Override
	public int deleteObjects(Integer... ids) {
		//1.参数有效性验证
		if(ids==null||ids.length==0)
		throw new IllegalArgumentException("请先选中记录");
		//2.执行删除操作
		int rows=0;
		try{
		rows=LogDao.deleteObjects(ids);
		}catch(Throwable e){
		e.printStackTrace();
		}
		//3.验证并返回结果
		if(rows==0)
			try {
				throw new ServiceException("记录可能已经不存在");
			} catch (ServiceException e) {
				e.printStackTrace();
			}
		return rows;
	}

	@Override
	public PageObject<Log> findPageObjects(
			String username,
			Integer pageCurrent) {
		//1.参数有效性验证(只验证pageCurrent)
		if(pageCurrent==null||pageCurrent<1)
		throw new IllegalArgumentException("页码值不正确");
		//2.查询总记录数并进行验证
		int rowCount=LogDao.getRowCount(username);
		if(rowCount==0)
			try {
				throw new ServiceException("没有对应记录");
			} catch (ServiceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//3.查询当前页日志数据
		int pageSize=2;
		int startIndex=(pageCurrent-1)*pageSize;
		List<Log> records=
		LogDao.findPageObjects(username,
				startIndex, pageSize);
		//4.对查询结果进行封装
		PageObject<Log> po=new PageObject<>();
		po.setRecords(records);
		po.setRowCount(rowCount);
		po.setPageSize(pageSize);
		po.setPageCurrent(pageCurrent);
	  /*int pageCount=rowCount/pageSize;
		if(rowCount%pageSize!=0){
			pageCount++;
		}*/
		//po.setPageCount((rowCount-1)/pageSize+1);
		//5.返回结果
		return po;
	}

	@Override
	public List<Log> getLogList() {
		List<Log> logList=LogDao.getLogList();
		return logList;
	}
}
