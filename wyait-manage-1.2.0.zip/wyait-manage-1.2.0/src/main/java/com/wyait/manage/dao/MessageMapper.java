package com.wyait.manage.dao;

import java.util.List;

import com.wyait.manage.pojo.Message;

public interface MessageMapper {
	
	int saveMessage(Message message);

	List<Message> queryMessage(Integer start, Integer l);
	
	int queryAll();
}
