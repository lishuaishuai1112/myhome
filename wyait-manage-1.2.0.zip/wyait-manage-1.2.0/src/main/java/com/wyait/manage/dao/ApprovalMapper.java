package com.wyait.manage.dao;

import com.wyait.manage.pojo.Vacate;

import java.util.List;

public interface ApprovalMapper {


    List<Vacate> selectApproval();
}
