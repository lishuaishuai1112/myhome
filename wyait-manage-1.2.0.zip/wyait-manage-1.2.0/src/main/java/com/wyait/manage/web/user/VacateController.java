package com.wyait.manage.web.user;

import com.wyait.manage.pojo.User;
import com.wyait.manage.pojo.Vacate;
import com.wyait.manage.service.VacateServiceImpl;
import org.apache.shiro.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 * @Auther: tedu
 * @Date: 2019/2/25 20:01
 * @Description:
 *请假申请
 */
@Controller
@RequestMapping("/vacate")
public class VacateController {
    private static final Logger logger = LoggerFactory
            .getLogger(AuthController.class);
    @Autowired
    private VacateServiceImpl service;
    @RequestMapping("/apply")
    public ModelAndView apply(Vacate vacate){
ModelAndView view=new ModelAndView();
view.addObject("vacate",vacate);
      view.setViewName("/vacate/apply");
      return view;
    }
    @RequestMapping("/submit")
    @ResponseBody
    public String submit(Vacate vacate){
        //获取shiro中当前登录系统的用户
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        //String username = user.getUsername();
      //  System.out.println(user.getUsername());
        vacate.setName(user.getUsername());
        logger.debug("请假数据开始提交!");
        String result="";
        try {
      int n= service.addVacate(vacate);
         System.out.println(n);
        result="请假提交成功";
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("请假提交异常！", e);
        result="请假提交失败,请稍后重试";
        }
        return result;
    }
}
