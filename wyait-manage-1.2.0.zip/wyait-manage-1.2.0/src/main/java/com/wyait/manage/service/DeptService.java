package com.wyait.manage.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wyait.manage.dao.DeptMapper;
import com.wyait.manage.dao.RoleMapper;
import com.wyait.manage.entity.DeptRoleDTO;
import com.wyait.manage.entity.DeptRolesVO;
import com.wyait.manage.entity.DeptSearchDTO;
import com.wyait.manage.pojo.Dept;
import com.wyait.manage.pojo.Role;
import com.wyait.manage.shiro.ShiroRealm;
import com.wyait.manage.utils.PageDataResult;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.mgt.RealmSecurityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @项目名称：wyait-manage
 * @包名：com.wyait.manage.service
 * @类描述：
 * @创建人：wyait
 * @创建时间：2017-12-20 15:53
 * @version：V1.0
 */
@Service
public class DeptService  {
	private static final Logger logger = LoggerFactory
			.getLogger(DeptService.class);
	@Autowired
	private DeptMapper deptMapper;
	@Autowired
	private RoleMapper roleMapper;

	public PageDataResult getdept(DeptSearchDTO deptSearch, int page, int limit) {

		PageDataResult pdr = new PageDataResult();
		PageHelper.startPage(page, limit);
		List<DeptRoleDTO> urList = deptMapper.getdept(deptSearch);
		// 获取分页查询后的数据
		PageInfo<DeptRoleDTO> pageInfo = new PageInfo<>(urList);
		// 设置获取到的总记录数total：
		pdr.setTotals(Long.valueOf(pageInfo.getTotal()).intValue());
		// 将角色名称提取到对应的字段中
		if (null != urList && urList.size() > 0) {
			for (DeptRoleDTO ur : urList) {
				List<Role> roles = roleMapper.getRoleByUserId(ur.getId());
				if (null != roles && roles.size() > 0) {
					StringBuilder sb = new StringBuilder();
					for (int i = 0; i < roles.size(); i++) {
						Role r = roles.get(i);
						sb.append(r.getRoleName());
						if (i != (roles.size() - 1)) {
							sb.append("，");
						}
					}
					ur.setRoleNames(sb.toString());
				}
			}
		}
		pdr.setList(urList);
		return pdr;
	}

	public String setDeldept(Integer id,
							 Integer version) {
		Dept datadept = this.deptMapper.selectByPrimaryKey(id);
		// 版本不一致
		if (null != datadept
				&& null != datadept.getVersion()
				&& !String.valueOf(version).equals(
				String.valueOf(datadept.getVersion()))) {
			return "操作失败，请您稍后再试";
		}
		return this.deptMapper.setDeldept(id) == 1 ? "ok"
				: "删除失败，请您稍后再试";
	}


	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 30000, rollbackFor = {
			RuntimeException.class, Exception.class })
	public String setdept(Dept dept) {
		int Id;
		if (dept.getId() != null) {
			// 判断用户是否已经存在
			Dept existdept = this.deptMapper.finddeptByname(dept.getName());
			if (null != existdept
					&& !String.valueOf(existdept.getId()).equals(
					String.valueOf(dept.getId()))) {
				return "该岗位名称已经存在";
			}
			Dept datadept = this.deptMapper.selectByPrimaryKey(dept.getId());
			// 版本不一致
			if (null != datadept
					&& null != datadept.getVersion()
					&& !String.valueOf(dept.getVersion()).equals(
					String.valueOf(datadept.getVersion()))) {
				return "操作失败，请您稍后再试";
			}
			// 更新用户
			Id = dept.getId();

			this.deptMapper.updateByPrimaryKeySelective(dept);

			// 方案一【不推荐】：通过SessionDAO拿到所有在线的用户，Collection<Session> sessions =
			// sessionDAO.getActiveSessions();
			// 遍历找到匹配的，更新他的信息【不推荐，分布式或用户数量太大的时候，会有问题。】；
			// 方案二【推荐】：用户信息价格flag（或version）标记，写个拦截器，每次请求判断flag（或version）是否改动，如有改动，请重新登录或自动更新用户信息（推荐）；

			// 清除ehcache中所有用户权限缓存，必须触发鉴权方法才能执行授权方法doGetAuthorizationInfo
			RealmSecurityManager rsm = (RealmSecurityManager) SecurityUtils
					.getSecurityManager();
			ShiroRealm authRealm = (ShiroRealm) rsm.getRealms().iterator()
					.next();
			authRealm.clearCachedAuth();
			logger.debug("清除所有用户权限缓存！！！");
		} else {
			// 判断用户是否已经存在

			Dept exist = this.deptMapper.finddeptByname(dept.getName());
			if (null != exist) {
				return "该用户名已经存在";
			}
			// 新增用户

			this.deptMapper.insert(dept);
			Id = dept.getId();
		}
		return "ok";
	}

	public DeptRolesVO getdeptAndRoles(Integer id) {
		// TODO Auto-generated method stub
		return this.deptMapper.getdeptAndRoles(id);
	}




}
