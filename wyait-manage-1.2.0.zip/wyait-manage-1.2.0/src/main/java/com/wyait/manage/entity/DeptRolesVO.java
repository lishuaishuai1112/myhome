package com.wyait.manage.entity;

public class DeptRolesVO {
	private Integer id;

	private String name;

	private Integer deptTel;

	private String introduce;


	private Integer version;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}


	public Integer getdeptTel() {
		return deptTel;
	}

	public void setdeptTel(Integer deptTel) {
		this.deptTel = deptTel;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "DeptRolesVO [id=" + id + ", name=" + name + ", deptTel=" + deptTel + ", introduce=" + introduce +
				", version=" + version + "]";
	}


}