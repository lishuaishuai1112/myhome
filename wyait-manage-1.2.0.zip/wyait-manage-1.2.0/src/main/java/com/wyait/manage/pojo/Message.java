package com.wyait.manage.pojo;

import java.util.Date;

public class Message {

	private Integer id;
	private String title;
	private String information;
	private String notifier;
	private Date time;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getInformation() {
		return information;
	}

	public void setInformation(String information) {
		this.information = information;
	}

	public String getNotifier() {
		return notifier;
	}

	public void setNotifier(String notifier) {
		this.notifier = notifier;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "message [id=" + id + ", title=" + title + ", information=" + information + ", notifier=" + notifier
				+ ", time=" + time + "]";
	}

}
