package com.wyait.manage.dao;

import com.wyait.manage.entity.QuartersRoleDTO;
import com.wyait.manage.entity.QuartersRolesVO;
import com.wyait.manage.entity.QuartersSearchDTO;
import com.wyait.manage.pojo.Quarters;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface QuartersMapper {

	List<Quarters> quarterstList(@Param("start") Integer start, @Param("limit") Integer limit);

	int quartersDelete(int id);

	int quartersUpdate(Quarters quarter);

	int quartersInsert(Quarters quarter);

	List<QuartersRoleDTO> getquarters(@Param("quartersSearch") QuartersSearchDTO quartersSearch);

	Quarters selectByPrimaryKey(Integer id);

	int setDelquarters(Integer id);

	Quarters findquartersByname(String name);

	void updateByPrimaryKeySelective(Quarters quarters);

	void insert(Quarters quarters);

	QuartersRolesVO getquartersAndRoles(Integer id);

    
}