package com.wyait.manage.service;

import com.wyait.common.utils.DateUtil;
import com.wyait.manage.dao.VacateMapper;
import com.wyait.manage.pojo.Vacate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.UUID;

/**
 * @Auther: tedu
 * @Date: 2019/2/26 16:55
 * @Description:
 */
@Service
public class VacateServiceImpl implements VacateService {
    @Autowired
    private VacateMapper mapper;

    //请假单提交
    @Transactional(rollbackFor={RuntimeException.class, Exception.class})
    public int addVacate(Vacate vacate) {
        String uuid="";
        for(int i=0;i<10;i++){
             uuid = UUID.randomUUID().toString().replaceAll("-", "");
        }
        vacate.setId(uuid);
        vacate.setAddDate(DateUtil.format(new Date()));
    mapper.getInsert(vacate);
        Vacate vacate1=mapper.selectVacate(vacate);
            mapper.updateStaAndNode(vacate1);
          return 1;
    }
}