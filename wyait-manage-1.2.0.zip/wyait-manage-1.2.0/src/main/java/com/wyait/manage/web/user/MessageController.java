package com.wyait.manage.web.user;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wyait.manage.pojo.Message;
import com.wyait.manage.service.MessageService;
import com.wyait.manage.utils.PageDataResult;

/**
 * 消息 功能实现
 * 
 * @author xht
 *
 */

@Controller
public class MessageController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	
	
	
	/**
	 * 管理员发送通知
	 * 
	 * @return 返回到send.html页面
	 */
	@RequestMapping("/message/send")
	public String messageSend() {
		System.out.println("发送通知");
		return "/message/send";
	}

	@Autowired
	private MessageService messageService;

	/**
	 * 管理员发送通知
	 * 
	 * @return 0---插入失败 1---插入成功
	 */
	@RequestMapping("/message/save")
	public String saveMessage(Message message) {
		System.out.println(message.getNotifier());
		
		int success = messageService.saveMessage(message);
		if (success == 1) {
			return "redirect:/home";
		}else {
			return "redirect:/message/send";
		}
	}

	@RequestMapping("/message/get")
	public String getMessage(){
		return "/message/messageList";
	}
	
	
	@RequestMapping(value = "/message/get", method = RequestMethod.POST)
	@ResponseBody
	public PageDataResult getUsers(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit
			) {
		logger.debug("分页查询用户列表！搜索条件：+ page:" + page + ",每页记录数量limit:" + limit);
		PageDataResult pdr =new PageDataResult();
		try {
			if (null == page) {
				page = 1;
			}
			if (null == limit) {
				limit = 10;
			}
			int start = (page-1)*limit;
			pdr = messageService.getMessage(start,limit);
			logger.debug("用户列表查询=pdr:" + pdr);
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("用户列表查询异常！", e);
		}
		return pdr;
	}
	
	
	
	/*@RequestMapping("/message/get1")
	@ResponseBody
	public List<Message> getMessage1(){
		return messageService.getMessage();
	}*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
