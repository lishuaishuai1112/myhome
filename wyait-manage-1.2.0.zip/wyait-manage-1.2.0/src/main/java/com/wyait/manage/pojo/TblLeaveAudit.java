package com.wyait.manage.pojo;


import java.io.Serializable;
import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;


/**
 * @实体名称 
 * @数表名称 TBL_LEAVE_AUDIT
 * @开发日期 2019-02-28
 * @技术服务 www.fwjava.com
 */
public class TblLeaveAudit implements Serializable {

    /**
     * 审批编号(必填项)(主键ID)
     */
    private Integer id            = null;
    /**
     * 请假编号与请假表对应
     */
    private Integer leaveId       = null;
    /**
     * 节点编号
     */
    private Integer flowNodeId    = null;
    /**
     * 审批人编号
     */
    private Integer userId        = null;
    /**
     * 审批人姓名
     */
    private String userName       = null;
    /**
     * 审批意见
     */
    private String auditInfo      = null;
    /**
     * 审批日期
     */
    private Date auditDate        = null;
    /**
     * 排序
     */
    private String orderBy        = null;

    /*
     *--------------------------------------------------
     * Getter方法区
     *--------------------------------------------------
     */

    /**
     * 审批编号(必填项)(主键ID)
     */
    public Integer getId() {
        return id;
    }
    /**
     * 请假编号与请假表对应
     */
    public Integer getLeaveId() {
        return leaveId;
    }
    /**
     * 节点编号
     */
    public Integer getFlowNodeId() {
        return flowNodeId;
    }
    /**
     * 审批人编号
     */
    public Integer getUserId() {
        return userId;
    }
    /**
     * 审批人姓名
     */
    public String getUserName() {
        return trim(userName);
    }
    /**
     * 审批意见
     */
    public String getAuditInfo() {
        return trim(auditInfo);
    }
    /**
     * 审批日期
     */
    public Date getAuditDate() {
        return auditDate;
    }
    /**
     * 排序
     */
    public String getOrderBy() {
        return trim(orderBy);
    }

    /*
     *--------------------------------------------------
     * Setter方法区
     *--------------------------------------------------
     */

    /**
     * 审批编号(必填项)(主键ID)
     */
    public void setId(Integer id) {
        this.id = id;
    }
    /**
     * 请假编号与请假表对应
     */
    public void setLeaveId(Integer leaveId) {
        this.leaveId = leaveId;
    }
    /**
     * 节点编号
     */
    public void setFlowNodeId(Integer flowNodeId) {
        this.flowNodeId = flowNodeId;
    }
    /**
     * 审批人编号
     */
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    /**
     * 审批人姓名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**
     * 审批意见
     */
    public void setAuditInfo(String auditInfo) {
        this.auditInfo = auditInfo;
    }
    /**
     * 审批日期
     */
    public void setAuditDate(Date auditDate) {
        this.auditDate = auditDate;
    }
    /**
     * 排序
     */
    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }


    /*
     *--------------------------------------------------
     * 常用自定义字段
     *--------------------------------------------------
     */
    /**
     * 审批人姓名(全模糊)
     */
    private String userNameLike          = null;
    /**
     * 审批意见(全模糊)
     */
    private String auditInfoLike         = null;
    /**
     * 审批日期(起始日期)
     */
    private String auditDateBegin        = null;
    /**
     * 审批日期(结束日期)
     */
    private String auditDateEnd          = null;

    /**
     * 审批人姓名(全模糊)
     */
    public String getUserNameLike() {
        return trim(userNameLike);
    }
    public void setUserNameLike(String userNameLike) {
        this.userNameLike = userNameLike;
    }
    /**
     * 审批意见(全模糊)
     */
    public String getAuditInfoLike() {
        return trim(auditInfoLike);
    }
    public void setAuditInfoLike(String auditInfoLike) {
        this.auditInfoLike = auditInfoLike;
    }
    /**
     * 审批日期(起始日期)
     */
    public String getAuditDateBegin() {
        return trim(auditDateBegin);
    }
    public void setAuditDateBegin(String auditDateBegin) {
        this.auditDateBegin = auditDateBegin;
    }
    /**
     * 审批日期(结束日期)
     */
    public String getAuditDateEnd() {
        return trim(auditDateEnd);
    }
    public void setAuditDateEnd(String auditDateEnd) {
        this.auditDateEnd = auditDateEnd;
    }
    /**
     * 审批日期(格式化)
     */
    public String getAuditDateChar() {
        return getDate(auditDate);
    }
    public void setAuditDateChar(String auditDateChar) {
        this.auditDate = getDate(auditDateChar);
    }
    /**
     * 审批日期(格式化)
     */
    public String getAuditDateCharAll() {
        return getDateTime(auditDate);
    }
    public void setAuditDateCharAll(String auditDateCharAll) {
        this.auditDate = getDate(auditDateCharAll);
    }

    /*
     *--------------------------------------------------
     * 应用小方法
     *--------------------------------------------------
     */

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    public String trim(String input)
    {
        return input==null?null:input.trim();
    }
    
    public String getDate(Date date)
    {
        if( null == date ) return "";
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }
    public String getDateTime(Date date)
    {
        if( null == date ) return "";
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }
    public Date getDate(String date)
    {
        if( null == date || date.trim().isEmpty() ) return null;
        date = date.trim();
        Date result = null;
        try {
            if( date.length() >= 19 )
            {
                result = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
            }
            else if( date.length() == 10 )
            {
                result = new SimpleDateFormat("yyyy-MM-dd").parse(date);
            }
        }
        catch (ParseException e) 
        {
            
        }
        return result;
    }

}


/** 
------------------------------------------------------
 Copy专用区
------------------------------------------------------

------------------------------------------------------------------------------------------------------------
  Setter方法
------------------------------------------------------------------------------------------------------------

// 
TblLeaveAudit tblLeaveAudit = new TblLeaveAudit();

// 审批编号(必填项)(主键ID)
tblLeaveAudit.setId(  );
// 请假编号与请假表对应
tblLeaveAudit.setLeaveId(  );
// 节点编号
tblLeaveAudit.setFlowNodeId(  );
// 审批人编号
tblLeaveAudit.setUserId(  );
// 审批人姓名
tblLeaveAudit.setUserName(  );
// 审批意见
tblLeaveAudit.setAuditInfo(  );
// 审批日期
tblLeaveAudit.setAuditDate(  );


//------ 自定义部分 ------

// 审批人姓名(全模糊)
tblLeaveAudit.setUserNameLike(  );
// 审批意见(全模糊)
tblLeaveAudit.setAuditInfoLike(  );
// 审批日期(起始日期)
tblLeaveAudit.setAuditDateBegin(  );
// 审批日期(结束日期)
tblLeaveAudit.setAuditDateEnd(  );
// 审批日期(格式化)
tblLeaveAudit.setAuditDateChar(  );


------------------------------------------------------------------------------------------------------------
  Getter方法
------------------------------------------------------------------------------------------------------------

// 
TblLeaveAudit tblLeaveAudit = new TblLeaveAudit();

// 审批编号(必填项)(主键ID)
tblLeaveAudit.getId();
// 请假编号与请假表对应
tblLeaveAudit.getLeaveId();
// 节点编号
tblLeaveAudit.getFlowNodeId();
// 审批人编号
tblLeaveAudit.getUserId();
// 审批人姓名
tblLeaveAudit.getUserName();
// 审批意见
tblLeaveAudit.getAuditInfo();
// 审批日期
tblLeaveAudit.getAuditDate();


//------ 自定义部分 ------

// 审批人姓名(全模糊)
tblLeaveAudit.getUserNameLike();
// 审批意见(全模糊)
tblLeaveAudit.getAuditInfoLike();
// 审批日期(起始日期)
tblLeaveAudit.getAuditDateBegin();
// 审批日期(结束日期)
tblLeaveAudit.getAuditDateEnd();
// 审批日期(格式化)
tblLeaveAudit.getAuditDateChar();


------------------------------------------------------------------------------------------------------------
  Getter Setter方法
------------------------------------------------------------------------------------------------------------

// 
TblLeaveAudit tblLeaveAudit = new TblLeaveAudit();

// 审批编号(必填项)(主键ID)
tblLeaveAudit.setId( tblLeaveAudit2.getId() );
// 请假编号与请假表对应
tblLeaveAudit.setLeaveId( tblLeaveAudit2.getLeaveId() );
// 节点编号
tblLeaveAudit.setFlowNodeId( tblLeaveAudit2.getFlowNodeId() );
// 审批人编号
tblLeaveAudit.setUserId( tblLeaveAudit2.getUserId() );
// 审批人姓名
tblLeaveAudit.setUserName( tblLeaveAudit2.getUserName() );
// 审批意见
tblLeaveAudit.setAuditInfo( tblLeaveAudit2.getAuditInfo() );
// 审批日期
tblLeaveAudit.setAuditDate( tblLeaveAudit2.getAuditDate() );


//------ 自定义部分 ------

// 审批人姓名(全模糊)
tblLeaveAudit.setUserNameLike( tblLeaveAudit2.getUserNameLike() );
// 审批意见(全模糊)
tblLeaveAudit.setAuditInfoLike( tblLeaveAudit2.getAuditInfoLike() );
// 审批日期(起始日期)
tblLeaveAudit.setAuditDateBegin( tblLeaveAudit2.getAuditDateBegin() );
// 审批日期(结束日期)
tblLeaveAudit.setAuditDateEnd( tblLeaveAudit2.getAuditDateEnd() );
// 审批日期(格式化)
tblLeaveAudit.setAuditDateChar( tblLeaveAudit2.getAuditDateChar() );



------------------------------------------------------------------------------------------------------------
 HTML标签区
------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------
  属性区
------------------------------------------------------------------------------------------------------------

<!-- 审批编号 -->
<input name="id" value="" type="text" maxlength="10"/>
<!-- 请假编号与请假表对应 -->
<input name="leaveId" value="" type="text" maxlength="10"/>
<!-- 节点编号 -->
<input name="flowNodeId" value="" type="text" maxlength="10"/>
<!-- 审批人编号 -->
<input name="userId" value="" type="text" maxlength="10"/>
<!-- 审批人姓名 -->
<input name="userName" value="" type="text" maxlength="20"/>
<!-- 审批意见 -->
<input name="auditInfo" value="" type="text" maxlength="100"/>
<!-- 审批日期 -->
<input name="auditDate" value="" type="text"/>


------------------------------------------------------------------------------------------------------------
  表名 + 属性区
------------------------------------------------------------------------------------------------------------

<!-- 审批编号 -->
<input name="tblLeaveAudit.id" value="" type="text" maxlength="10"/>
<!-- 请假编号与请假表对应 -->
<input name="tblLeaveAudit.leaveId" value="" type="text" maxlength="10"/>
<!-- 节点编号 -->
<input name="tblLeaveAudit.flowNodeId" value="" type="text" maxlength="10"/>
<!-- 审批人编号 -->
<input name="tblLeaveAudit.userId" value="" type="text" maxlength="10"/>
<!-- 审批人姓名 -->
<input name="tblLeaveAudit.userName" value="" type="text" maxlength="20"/>
<!-- 审批意见 -->
<input name="tblLeaveAudit.auditInfo" value="" type="text" maxlength="100"/>
<!-- 审批日期 -->
<input name="tblLeaveAudit.auditDate" value="" type="text"/>


------------------------------------------------------------------------------------------------------------
  ID + 属性区
------------------------------------------------------------------------------------------------------------

<!-- 审批编号 -->
<input id="TLA_ID" name="id" value="" type="text" maxlength="10"/>
<!-- 请假编号与请假表对应 -->
<input id="TLA_LEAVE_ID" name="leaveId" value="" type="text" maxlength="10"/>
<!-- 节点编号 -->
<input id="TLA_FLOW_NODE_ID" name="flowNodeId" value="" type="text" maxlength="10"/>
<!-- 审批人编号 -->
<input id="TLA_USER_ID" name="userId" value="" type="text" maxlength="10"/>
<!-- 审批人姓名 -->
<input id="TLA_USER_NAME" name="userName" value="" type="text" maxlength="20"/>
<!-- 审批意见 -->
<input id="TLA_AUDIT_INFO" name="auditInfo" value="" type="text" maxlength="100"/>
<!-- 审批日期 -->
<input id="TLA_AUDIT_DATE" name="auditDate" value="" type="text"/>


------------------------------------------------------------------------------------------------------------
  ID + 表名 + 属性区
------------------------------------------------------------------------------------------------------------

<!-- 审批编号 -->
<input id="TLA_ID" name="tblLeaveAudit.id" value="" type="text" maxlength="10"/>
<!-- 请假编号与请假表对应 -->
<input id="TLA_LEAVE_ID" name="tblLeaveAudit.leaveId" value="" type="text" maxlength="10"/>
<!-- 节点编号 -->
<input id="TLA_FLOW_NODE_ID" name="tblLeaveAudit.flowNodeId" value="" type="text" maxlength="10"/>
<!-- 审批人编号 -->
<input id="TLA_USER_ID" name="tblLeaveAudit.userId" value="" type="text" maxlength="10"/>
<!-- 审批人姓名 -->
<input id="TLA_USER_NAME" name="tblLeaveAudit.userName" value="" type="text" maxlength="20"/>
<!-- 审批意见 -->
<input id="TLA_AUDIT_INFO" name="tblLeaveAudit.auditInfo" value="" type="text" maxlength="100"/>
<!-- 审批日期 -->
<input id="TLA_AUDIT_DATE" name="tblLeaveAudit.auditDate" value="" type="text"/>




--------------------------------------------------------
 */


    