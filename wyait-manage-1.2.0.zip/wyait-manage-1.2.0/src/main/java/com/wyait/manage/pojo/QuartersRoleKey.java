package com.wyait.manage.pojo;

public class QuartersRoleKey {
    private Integer Id;

    private Integer roleId;

    public Integer getId() {
        return Id;
    }

    public void setId(Integer Id) {
        this.Id = Id;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    @Override public String toString() {
        return "UserRoleKey{" + "Id=" + Id + ", roleId=" + roleId + '}';
    }
}