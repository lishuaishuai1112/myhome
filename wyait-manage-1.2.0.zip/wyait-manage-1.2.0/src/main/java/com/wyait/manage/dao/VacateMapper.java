package com.wyait.manage.dao;

import com.wyait.manage.pojo.Vacate;

public interface VacateMapper {


 int getInsert(Vacate vacate);

 void updateStaAndNode(Vacate vacate);

    Vacate selectVacate(Vacate vacate);
}
