package com.wyait.manage.exception;

public class ServiceException extends Exception {

	
	private static final long serialVersionUID = -2850276659806418376L;
	public ServiceException() {
		super();
	}
public ServiceException(String string) {
		
	}
	public ServiceException(Throwable cause) {
		super(cause);
	}
}
