package com.wyait.manage.web.quarters;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.cache.ehcache.EhCacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wyait.manage.entity.QuartersRolesVO;
import com.wyait.manage.entity.QuartersSearchDTO;
import com.wyait.manage.entity.ResponseResult;
import com.wyait.manage.pojo.Quarters;
import com.wyait.manage.pojo.User;
import com.wyait.manage.service.AuthService;
import com.wyait.manage.service.QuartersService;
import com.wyait.manage.utils.IStatusMessage;
import com.wyait.manage.utils.PageDataResult;

import net.sf.oval.ConstraintViolation;
import net.sf.oval.Validator;

/**
 * @项目名称：wyait-manage
 * @包名：com.wyait.manage.web.user
 * @类描述：
 * @创建人：wyait
 * @创建时间：2017-12-31 14:22
 * @version：V1.0
 */
@Controller
@RequestMapping("/quarters")
public class QuartersController {

	private static final Logger logger = LoggerFactory
			.getLogger(QuartersController.class);
	@Autowired
	private QuartersService quartersService;
	@Autowired
	private AuthService authService;
	@Autowired
	private EhCacheManager ecm;

	//private static final Pattern MOBILE_PATTERN = Pattern.compile("^1\\d{10}$");

	@RequestMapping("/quartersList")
	public String toquartersList() {
		return "/auth/quartersList";
	}

	/**
	 * 分页查询用户列表
	 * @return ok/fail
	 */
	@RequestMapping(value = "/getquarters", method = RequestMethod.POST)
	@ResponseBody
	@RequiresPermissions(value = "quartersmanage")
	public PageDataResult getquarters(@RequestParam("page") Integer page,
			@RequestParam("limit") Integer limit, QuartersSearchDTO quartersSearch) {
		logger.debug("分页查询用户列表！搜索条件：quartersSearch：" +quartersSearch + ",page:" + page
				+ ",每页记录数量limit:" + limit);
		PageDataResult pdr = new PageDataResult();
		try {
			if (null == page) {
				page = 1;
			}
			if (null == limit) {
				limit = 10;
			}
			// 获取用户和角色列表
			pdr = quartersService.getquarters(quartersSearch, page, limit);
			logger.debug("岗位列表查询=pdr:" + pdr);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("岗位列表查询异常！", e);
		}
		return pdr;
	}

	
	/**
	 * 设置用户[新增或更新]
	 * @return ok/fail
	 */
	@RequestMapping(value = "/setquarters", method = RequestMethod.POST)
	@ResponseBody
	public String setquarters( Quarters quarters) {
		logger.debug("设置用户[新增或更新]！user:" + quarters );
		try {
			if (null == quarters) {
				logger.debug("置岗位[新增或更新]，结果=请您填写岗位信息");
				return "请您填写岗位信息";
			}
			User existuser = (User) SecurityUtils.getSubject().getPrincipal();
			if (null == existuser) {
				logger.debug("置岗位[新增或更新]，结果=您未登录或登录超时，请您登录后再试");
				return "您未登录或登录超时，请您登录后再试";
			}
			// 设置用户[新增或更新]
			logger.info("设置用户[新增或更新]成功！quarters=" + quarters   
					+ "，操作的用户ID=" + existuser.getId());
			return quartersService.setquarters(quarters);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("设置岗位[新增或更新]异常！", e);
			return "操作异常，请您稍后再试";
		}
	}

	/**
	 * 删除用户
	 * @return ok/fail
	 */
	@RequestMapping(value = "/delquarters", method = RequestMethod.POST)
	@ResponseBody
	public String delquarters(@RequestParam("id") Integer id,
			@RequestParam("version") Integer version) {
		logger.debug("删除岗位！id:" + id + ",version:" + version);
		String msg = "";
		try {
			if (null == id || null == version) {
				logger.debug("删除岗位，结果=请求参数有误，请您稍后再试");
				return "请求参数有误，请您稍后再试";
			}
			User existuser = (User) SecurityUtils.getSubject().getPrincipal();
			if (null == existuser) {
				logger.debug("删除岗位，结果=您未登录或登录超时，请您登录后再试");
				return "您未登录或登录超时，请您登录后再试";
			}
			// 删除用户
			msg = quartersService.setDelquarters(id, version);
			logger.info("删除岗位:" + msg + "！quartersId=" + id + "，操作岗位id:"
					+ existuser.getId() + ",version:" + version);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("删除岗位异常！", e);
			msg = "操作异常，请您稍后再试";
		}
		return msg;
	}

	/**
	 *
	 * @描述：恢复用户
	 * @创建人：wyait
	 * @创建时间：2018年4月27日 上午9:49:14
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/recoverquarters", method = RequestMethod.POST)
	@ResponseBody
	public String recoverUser(@RequestParam("id") Integer id,
			@RequestParam("version") Integer version) {
		logger.debug("恢复岗位！id:" + id + ",version:" + version);
		String msg = "";
		try {
			User existUser = (User) SecurityUtils.getSubject().getPrincipal();
			if (null == existUser) {
				return "您未登录或登录超时，请您登录后再试";
			}
			if (null == id || null == version) {
				return "请求参数有误，请您稍后再试";
			}
			// 删除用户
			msg = quartersService.setDelquarters(id,version);
			logger.info("恢复岗位【" + this.getClass().getName() + ".recoverquarters】"
					+ msg + "。用户quartersId=" + id + "，操作的用户ID=" + existUser.getId() + ",version:" + version);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("恢复用户【" + this.getClass().getName()
					+ ".recoverquarters】用户异常！", e);
			msg = "操作异常，请您稍后再试";
		}
		return msg;
	}

	/**
	 * 查询用户数据
	 * @return map
	 */
	@RequestMapping(value = "/getquartersAndRoles", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> getQuartersAndRoles(@RequestParam("id") Integer id) {
		logger.debug("查询岗位数据！id:" + id);
		Map<String, Object> map = new HashMap<>();
		try {
			if (null == id) {
				logger.debug("查询岗位数据==请求参数有误，请您稍后再试");
				map.put("msg", "请求参数有误，请您稍后再试");
				return map;
			}
			// 查询用户
			QuartersRolesVO urvo = quartersService.getquartersAndRoles(id);
			logger.debug("查询岗位数据！urvo=" + urvo);
			if (null != urvo) {
				map.put("quarters", urvo);
			} else {
				map.put("msg", "查询岗位信息有误，请您稍后再试");
			}
			map.put("msg", "ok");
			logger.debug("查询岗位数据成功！map=" + map);
			return map;
		} catch (Exception e) {
			e.printStackTrace();
			map.put("msg", "查询岗位错误，请您稍后再试");
			logger.error("查询岗位数据异常！", e);
		}
		return map;
	}

	/**
	 * @描述：校验请求参数
	 * @param obj
	 * @param response
	 * @return
	 */
	protected boolean validatorRequestParam(Object obj, ResponseResult response) {
		boolean flag = false;
		Validator validator = new Validator();
		List<ConstraintViolation> ret = validator.validate(obj);
		if (ret.size() > 0) {
			// 校验参数有误
			response.setCode(IStatusMessage.SystemStatus.PARAM_ERROR.getCode());
			response.setMessage(ret.get(0).getMessageTemplate());
		} else {
			flag = true;
		}
		return flag;
	}
}