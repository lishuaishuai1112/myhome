package com.wyait.manage.service;

import com.wyait.manage.pojo.Vacate;

public interface VacateService {
   //请假单提交
    int addVacate(Vacate vacate);
}
