package com.wyait.manage.service;

import com.wyait.manage.dao.ApprovalMapper;
import com.wyait.manage.pojo.Vacate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Auther: tedu
 * @Date: 2019/2/28 13:43
 * @Description:
 */
@Service
public class ApprovalServiceImpl implements   ApprovalService {
   @Autowired
    private ApprovalMapper mapper;
    public List<Vacate> getAllVacate(){
        return mapper.selectApproval();
    }
}
