package com.wyait.manage.service;

import java.util.List;

import com.wyait.manage.pojo.Message;
import com.wyait.manage.utils.PageDataResult;

/**
 * 通知的service接口
 * @author 谢洪涛
 *
 */
public interface MessageService {

	/**
	 * 管理员新增通知
	 * @return
	 */
	public int saveMessage(Message message);

	public PageDataResult getMessage(Integer start, Integer limit);

}
