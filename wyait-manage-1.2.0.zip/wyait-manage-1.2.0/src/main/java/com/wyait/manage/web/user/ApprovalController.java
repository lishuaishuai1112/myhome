package com.wyait.manage.web.user;

import com.wyait.manage.pojo.Vacate;
import com.wyait.manage.service.ApprovalService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: tedu
 * @Date: 2019/2/28 13:29
 * @Description:
 */
@Controller
@RequestMapping("/approval")
public class ApprovalController {
    @Autowired
    private ApprovalService service;
    @RequestMapping("tomy")
   @RequiresPermissions(value = "approvaltomy")
    public String myapproval(){
        ModelAndView view=new ModelAndView();
        List<Vacate>list=new ArrayList<Vacate>();
        list=service.getAllVacate();
        view.addObject("approval",list);
        view.setViewName("approvalList");
        return "/approval/list";
    }
}
