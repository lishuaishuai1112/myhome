package com.wyait.manage.entity;

import java.util.List;

import com.wyait.manage.pojo.UserRoleKey;

public class QuartersRolesVO {
	private Integer id;

	private String name;

	private Integer deptno;

	private String introduce;


	private Integer version;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	
	public Integer getDeptno() {
		return deptno;
	}

	public void setDeptno(Integer deptno) {
		this.deptno = deptno;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "QuartersRolesVO [id=" + id + ", name=" + name + ", deptno=" + deptno + ", introduce=" + introduce + 
				  ", version=" + version + "]";
	}

	
}