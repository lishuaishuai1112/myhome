/**
 * 用户管理
 */
var pageCurr;
$(function() {
    layui.use('table', function(){
        var table = layui.table
            ,form = layui.form;

        tableIns=table.render({
            elem: '#uesrList'
            ,url:'/user/getUsers'
            ,method: 'post' //默认：get请求
            ,cellMinWidth: 80
            ,page: true,
            request: {
                pageName: 'page' //页码的参数名称，默认：page
                ,limitName: 'limit' //每页数据量的参数名，默认：limit
            },response:{
                statusName: 'code' //数据状态的字段名称，默认：code
                ,statusCode: 200 //成功的状态码，默认：0
                ,countName: 'totals' //数据总数的字段名称，默认：count
                ,dataName: 'list' //数据列表的字段名称，默认：data
            }
            ,cols: [[
                {type:'numbers'}
                ,{field:'id', title:'ID',width:80, unresize: true, sort: true}
                ,{field:'username', title:'用户名'}
                ,{field:'mobile', title:'手机号'}
                ,{field:'insertTime', title: '添加时间'}

            ]]
            ,  done: function(res, curr, count){
                //如果是异步请求数据方式，res即为你接口返回的信息。
                //如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
                //console.log(res);
                //得到当前页码
                //console.log(curr);
                //得到数据总量
                //console.log(count);
                pageCurr=curr;
            }
        });
        /**
         * 角色列表
         */
        $(function() {
            layui.use('table', function(){
                var table = layui.table;
                var tbody=$("#tbody");
                $.get("/log/getLogList",function(data){
                    if(data!=null){
                        tbody.empty();

                        $.each(data, function (index, item) {
                           // debugger
                            var td=$("<tr><td>"+item.userName+"</td>"
                                +"<td>"+item.result+"</td>"
                                +"<td>"+item.ip+"</td>"
                                +"<td>"+DateUtils.formatDate(item.time)+"</td></tr>");
                            tbody.append(td);
                        });
                    }
                });
            });
        });





        function updateRole(id) {
            //isNaN是数字返回false
            if(id!=null && !isNaN(id)){
                window.location.href="/auth/updateRole/"+id+"?callback="+getCallback();
            }else{
                layer.alert("请求参数有误，请您稍后再试");
            }
        }
        function delRole(id) {
            if(null!=id){
                layer.confirm('您确定要删除'+name+'角色吗？', {
                    btn: ['确认','返回'] //按钮
                }, function(){
                    $.post("/auth/delRole",{"id":id},function(data){
                        if(data=="ok"){
                            //回调弹框
                            layer.alert("删除成功！",function(){
                                layer.closeAll();
                                //加载load方法
                                load();//自定义
                            });
                        }else{
                            layer.alert(data);//弹出错误提示
                        }
                    });
                }, function(){
                    layer.closeAll();
                });
            }
        }
//搜索框
        layui.use(['form','laydate'], function(){
            var form = layui.form ,layer = layui.layer
                ,laydate = layui.laydate;
            //日期
            laydate.render({
                elem: '#insertTimeStart'
            });
            laydate.render({
                elem: '#insertTimeEnd'
            });
            //TODO 数据校验
            //监听搜索框
            form.on('submit(searchSubmit)', function(data){
                //重新加载table
                load(data);
                return false;
            });
        });
    });
});

