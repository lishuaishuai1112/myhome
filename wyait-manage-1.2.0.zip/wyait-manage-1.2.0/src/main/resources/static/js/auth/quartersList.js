/**
 * 岗位管理
 */
var pageCurr;
$(function() {
    layui.use('table', function(){
        var table = layui.table
            ,form = layui.form;

        tableIns=table.render({
            elem: '#quartersList'
            ,url:'/quarters/getquarters'
            ,method: 'post' //默认：get请求
            ,cellMinWidth: 80
            ,page: true,
            request: {
                pageName: 'page' //页码的参数名称，默认：page
                ,limitName: 'limit' //每页数据量的参数名，默认：limit
            },response:{
                statusName: 'code' //数据状态的字段名称，默认：code
                ,statusCode: 200 //成功的状态码，默认：0
                ,countName: 'totals' //数据总数的字段名称，默认：count
                ,dataName: 'list' //数据列表的字段名称，默认：data
            }
            ,cols: [[
                {type:'numbers'}
                ,{field:'id', title:'ID',width:80, unresize: true, sort: true}
                ,{field:'name', title:'岗位名称'}
                ,{field:'deptno', title:'部门编号'}
                ,{field:'introduce', title: '岗位简介'}
                ,{fixed:'right', title:'操作',width:140,align:'center', toolbar:'#optBar'}
            ]]
            ,  done: function(res, curr, count){
                //如果是异步请求数据方式，res即为你接口返回的信息。
                //如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
                //console.log(res);
                //得到当前页码
                //console.log(curr);
                //得到数据总量
                //console.log(count);
                pageCurr=curr;
            }
        });

        //监听在职操作
        form.on('switch(isJobTpl)', function(obj){
            //console.log(this.value + ' ' + this.name + '：'+ obj.elem.checked, obj.othis);
            setJobUser(obj,this.value,this.name,obj.elem.checked);
        });
        //监听工具条
        table.on('tool(quartersTable)', function(obj){
            var data = obj.data;
            if(obj.event === 'del'){
                delquarters(data,data.id,data.name);
            } else if(obj.event === 'edit'){
                //编辑
                getquartersAndRoles(data,data.id);
            } else if(obj.event === 'recover'){
                //恢复
                recoverquarters(data,data.id);
            }
        });
        //监听提交
        form.on('submit(quartersSubmit)', function(data){
            // TODO 校验
            formSubmit(data);
            return false;
        });

    });
    //搜索框
    layui.use(['form','laydate'], function(){
        var form = layui.form ,layer = layui.layer
            ,laydate = layui.laydate;
        //日期
        laydate.render({
            elem: '#insertTimeStart'
        });
        laydate.render({
            elem: '#insertTimeEnd'
        });
        //TODO 数据校验
        //监听搜索框
        form.on('submit(searchSubmit)', function(data){
            //重新加载table
            load(data);
            return false;
        });
    });
});

//提交表单
function formSubmit(obj){
    var currentquarters=$("#currentquarters").html();
            layer.confirm('您确定要更新么?', {
                btn: ['返回','确认'] //按钮
            },function(){
                layer.closeAll();
            },function() {
                layer.closeAll();//关闭所有弹框
                submitAjax(obj,currentquarters);
            });
}
function submitAjax(obj,currentquarters){
    $.ajax({
        type: "POST",
        data: $("#quartersForm").serialize(),
        url: "/quarters/setquarters",
        success: function (data) {
                if (data == "ok") {
                    layer.alert("操作成功",function(){
                            layer.closeAll();
                            cleanquarters();
                            //$("#id").val("");
                            //加载页面
                            load(obj);

                    });
                } else {
                    layer.alert(data,function(){
                        layer.closeAll();
                        //加载load方法
                        load(obj);//自定义
                    });
                }

        },
        error: function () {
            layer.alert("操作请求错误，请您稍后再试",function(){
                layer.closeAll();
                //加载load方法
                load(obj);//自定义
            });
        }
    });
}


function delquarters(obj,id,name) {
    var currentUser=$("#currentUser").html();
    var version=obj.version;
    if(null!=id){

            layer.confirm('您确定要删除'+name+'岗位吗？', {
                btn: ['确认','返回'] //按钮
            }, function(){
                $.post("/quarters/delquarters",{"id":id,"version":version},function(data){
                    if(isLogin(data)){
                        if(data=="ok"){
                            //回调弹框
                            layer.alert("删除成功！",function(){
                                layer.closeAll();
                                //加载load方法
                                load(obj);//自定义
                            });
                        }else{
                            layer.alert(data,function(){
                                layer.closeAll();
                                //加载load方法
                                load(obj);//自定义
                            });
                        }
                    }
                });
            }, function(){
                layer.closeAll();
            });

    }
}
function recoverquarters(obj,id) {
    //console.log("需要恢复的用户id="+id);
    var version=obj.version;
    //console.log("delUser版本:"+version);
    if(null!=id){
        layer.confirm('您确定要恢复'+name+'岗位吗？', {
            btn: ['确认','返回'] //按钮
        }, function(){
            $.post("/quarters/recoverquarters",{"id":id,"version":version},function(data){
                if(isLogin(data)){
                    if(data=="ok"){
                        //回调弹框
                        layer.alert("恢复成功！",function(){
                            layer.closeAll();
                            //加载load方法
                            load(obj);//自定义
                        });
                    }else{
                        layer.alert(data,function(){
                            layer.closeAll();
                            //加载load方法
                            load(obj);//自定义
                        });
                    }
                }
            });
        }, function(){
            layer.closeAll();
        });
    }
}

function openquarters(id,title){
    layer.open({
        type:1,
        title: title,
        fixed:false,
        resize :false,
        shadeClose: true,
        area: ['550px'],
        content:$('#setquarters'),
        end:function(){
            cleanquarters();
        }
    });
}



function getquartersAndRoles(obj,id) {
    //如果已经离职，提醒不可编辑和删除
        //回显数据
        $.get("/quarters/getquartersAndRoles",{"id":id},function(data){
            if(isLogin(data)){
                if(data.msg=="ok" && data.quarters!=null){
                	$("#id").val(data.quarters.id==null?'':data.quarters.id);
                	$("#qname").val(data.quarters.name==null?'':data.quarters.name);
                	$("#qdeptno").val(data.quarters.deptno==null?'':data.quarters.deptno);
                	$("#introduce").val(data.quarters.introduce==null?'':data.quarters.introduce);
                    $("#version").val(data.quarters.version==null?'':data.quarters.version);
                    openquarters(id,"设置用户");
                }else{
                    //弹出错误提示
                    layer.alert(data.msg,function () {
                        layer.closeAll();
                    });
                }
            }
        });

}

function addquarters(){
    $.get("/auth/getRoles",function(data){
        if(isLogin(data)){
            if(data!=null){
                //显示角色数据
                $("#roleDiv").empty();
                $.each(data, function (index, item) {
                    // <input type="checkbox" name="roleId" title="发呆" lay-skin="primary"/>
                    var roleInput=$("<input type='checkbox' name='roleId' value="+item.id+" title="+item.roleName+" lay-skin='primary'/>");
                    //未选中
                    /*<div class="layui-unselect layui-form-checkbox" lay-skin="primary">
                        <span>发呆</span><i class="layui-icon">&#xe626;</i>
                        </div>*/
                    //选中
                    // <div class="layui-unselect layui-form-checkbox layui-form-checked" lay-skin="primary">
                    // <span>写作</span><i class="layui-icon">&#xe627;</i></div>
                    var div=$("<div class='layui-unselect layui-form-checkbox' lay-skin='primary'>" +
                        "<span>"+item.roleName+"</span><i class='layui-icon'>&#xe626;</i>" +
                        "</div>");
                    $("#roleDiv").append(roleInput).append(div);
                })
                openquarters(null,"添加岗位");
            }else{
                //弹出错误提示
                layer.alert("获取角色数据有误，请您稍后再试",function () {
                    layer.closeAll();
                });
            }
        }
    });
}


function load(obj){
    //重新加载table
    tableIns.reload({
        where: obj.field
        , page: {
            curr: pageCurr //从当前页码开始
        }
    });
}

function cleanquarters(){
    $("#id").val("");
    $("#name").val("");
    $("#deptno").val("");
    $("#introduce").val("");
}