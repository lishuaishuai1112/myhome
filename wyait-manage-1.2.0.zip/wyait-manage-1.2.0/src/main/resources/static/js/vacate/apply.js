$(function(){
    layui.use(['form' ,'layer'], function() {
       // debugger;
        var form = layui.form;
        var layer = layui.layer;
        监控提交
        form.on("submit(login)",function () {
            login();
        });
    })
})
function login() {
    $.post("/vacate/submit",$("#login1").serialize(),function(data){
        console.log("data:"+data+"jh")
        layer.alert(data,function () {
           layer.closeAll();
        })
    });
}
